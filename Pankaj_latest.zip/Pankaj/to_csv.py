#-------------------------------------------------------------------------------
# Name:        to_csv
#-------------------------------------------------------------------------------

from myXLS import fast_openpyxl
import os,argparse
import jinja2
import csv

def clear_screen():
    os.system('cls' if os.name == 'nt' else 'clear')
    print("\n\n")

clear_screen()

def main():
    parser = argparse.ArgumentParser(description=":: to create csv files ::")
    parser.add_argument('-x', '--xls', dest="xls", type=str, default=None, required=True, help='input xls file')

    args = parser.parse_args()
    xlFile = args.xls

    (_, wb) = fast_openpyxl(xlFile)

    output_path = rf'output\{xlFile.split(".")[0].split("_")[-1]}'

    try:
        if os.path.isdir(output_path) and os.access(output_path, os.W_OK):
            print(f"Directory {output_path} exists and Writable")
        else:
            print("Directory output not found, creating it")
            os.mkdir(rf'{output_path}')

    except FileNotFoundError:
        print(f"Directory [{output_path}] output not found, creating it")

    ##{{ "Hello" if item is none else item }}
    # Define the template
    template = jinja2.Template("""
    {%- for key, value in data.items() %}
    {{ key | trim }},{{ value if value != "None"  else "" }}
    {%- endfor %}
    """)

    ##print(wb['sheet_Values'])
    for row in wb['sheet_Automated']:
        if row['source_vc'] != '0':
    ##        print(row)
            csv_data = template.render(data=row)
    ##        print(csv_data)
                # Write the CSV data to a file
            cFile = f'{output_path}\phase3_{row["SourceCluster"]}.csv'
            if csv_data[0] == '\n':
                csv_data = csv_data.lstrip(csv_data[0])
            print(f"creating file: {cFile}...")
            with open(cFile, "w") as f:
                f.write(csv_data)


if __name__ == '__main__':
    main()
