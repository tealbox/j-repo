import json, os
from myNSX import myNSX
import re
from readXl import *
import argparse, getpass


def extract_numbers_from_end(s):
    numbers = re.findall(r'\d+$', s)
    if len(numbers):
        vlan = int(numbers[0])
        if 0<= vlan <= 4096:
            return int(numbers[0])
        else:
            print('%s: VLAN Format should be like xxxdddd & dddd must be in range 0-4096' % s)
            raise SystemExit()
    else:
        print('%s: VLAN Format should be like xxxdddd' % s)
        raise SystemExit()

class nsxProfile(myNSX):

    def __init__(self, nsxmgr, username = "admin", password = "VMware1!"):
        super().__init__(nsxmgr, username=username, password = password)
        self.mgrUrl = f"https://{nsxmgr}/api/v1"

    def getUplinkProfiles(self):
        api = "/host-switch-profiles"
        url = f"{self.mgrUrl}{api}"
        self.ups = {}
        results = self.get(api=url)
        for item in results['results']:
            self.ups.setdefault(item['display_name'], item['id'])

    def createUPPayload(self,name,file="ulProfilePayload.json"):
        import json
        with open(file) as f:
            payload = json.load(f)
            vlan = extract_numbers_from_end(name)
            payload['transport_vlan'] = vlan
            payload['display_name'] = name
            return json.dumps(payload)

    def createUplinkProfile(self,name,file="ulProfilePayload.json"):
        payload = self.createUPPayload(name,file)
        api = "/host-switch-profiles"
        url = f"{self.mgrUrl}{api}"
        self.getUplinkProfiles()
        if name in self.ups:
            print("Uplink Profile %s already exist" % name)
        else:
            print("Creating Uplink Profile %s"%name)
            self.post(api=url,payload=payload)

    def deletUplinkProfile(self,name,file="ulProfilePayload.json"):
        payload = self.createUPPayload(name,file)
        api = "/host-switch-profiles"
        url = f"{self.mgrUrl}{api}"
        self.post(api=url,payload=payload)

    def getipPool(self):
        api = "/pools/ip-pools"
        url = f"{self.mgrUrl}{api}"
        self.ippools = {}
        results = self.get(api=url)
        for item in results['results']:
            self.ippools.setdefault(item['display_name'], item['id'])


    def getTransportZones(self):
        api = "/transport-zones"
        url = f"{self.mgrUrl}{api}"
        self.tz = {}
        results = self.get(api=url)
        for item in results['results']:
            self.tz.setdefault(item['display_name'], item['id'])

class Password(argparse.Action):
    def __call__(self, parser, namespace, values, option_string):
        if values is None:
            values = getpass.getpass()

        setattr(namespace, self.dest, values)

def main():
    parser = argparse.ArgumentParser(description=":: PortGroup Create ::")
    parser.add_argument('-x', '--xls', dest="xls", type=str, default=None, required=True, help='input xls file')
    parser.add_argument('-n', '--nsxmgr', dest="nsxmgr", type=str, default=None, required=True, help='nsxmgr IP/FQDN')
    parser.add_argument('-u', '--username', dest="username", type=str, default=None, required=True,help='nsxmgr username')
    parser.add_argument('-p', action=Password, nargs='?', dest='password', help='nsxmgr Password')
    args = parser.parse_args()
    xlsFile = args.xls
    print("--"*25)
    a =  nsxProfile(nsxmgr=args.nsxmgr, username = args.username, password = args.password)
    ulprofiles = readColumns(xlsFile, sheet ='Values', col='D', row=16)
##    a.getUplinkProfiles()
##    payload = a.createUPPayload("TNP-PDV-C-VSI-HCI-MVL3721-TVL3799")
##    print(payload)
    for item in ulprofiles:
        a.createUplinkProfile(item)



if __name__ == "__main__":
    main()