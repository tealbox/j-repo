import atexit
import sys, re
import time, openpyxl

from pyVmomi import vim, vmodl
from pyvim import connect
from pyvim.connect import Disconnect
from ExcelColumnIterator import *
import argparse, getpass
import ssl
context = ssl.create_default_context()
context.check_hostname = False
context.verify_mode = ssl.CERT_NONE

def get_obj(content, vimtype, name):
    """
     Get the vsphere object associated with a given text name
    """
    obj = None
    container = content.viewManager.CreateContainerView(content.rootFolder, vimtype, True)
    for c in container.view:
        if c.name == name:
            obj = c
            break
    return obj
class CustomException(BaseException):
    """Custom exception class"""
    pass

def wait_for_task(task, actionName='job', hideResult=False):
    """
    Waits and provides updates on a vSphere task
    """
    from contextlib import suppress

    with suppress(Exception):
        while task.info.state == vim.TaskInfo.State.running:
            time.sleep(2)

        if task.info.state == vim.TaskInfo.State.success:
            if task.info.result is not None and not hideResult:
                out = '%s completed successfully, result: %s' % (actionName, task.info.result)
                print(out)
            else:
                out = '%s completed successfully.' % actionName
                print(out)
        else:
            out = '%s did not complete successfully: %s' % (actionName, task.info.error)
            raise task.info.error
            print (out)

        return task.info.result

import argparse, getpass

class Password(argparse.Action):
    def __call__(self, parser, namespace, values, option_string):
        if values is None:
            values = getpass.getpass()

        setattr(namespace, self.dest, values)

def main():
    parser = argparse.ArgumentParser(description=":: PortGroup Create ::")
    parser.add_argument('-x', '--xls', dest="xls", type=str, default=None, required=True, help='input xls file')
    parser.add_argument('-vc', '--vcenter', dest="vcenter", type=str, default=None, required=True, help='vCenter IP/FQDN')
    parser.add_argument('-u', '--username', dest="username", type=str, default=None, required=True,help='vCenter username')
    parser.add_argument('-p', action=Password, nargs='?', dest='password', help='vCenter Password')
    args = parser.parse_args()
    xlsFile = args.xls

   # xlsFile = "vc_inputs_schwab.xlsx"
    wb = openpyxl.load_workbook(xlsFile,data_only=True)
    ws = wb.active
    iterator = ExcelColumnIterator(num='D')
    try:
        si = None
        try:
            print ("Trying to connect to VCENTER SERVER . . .")
            si = connect.Connect(args.vcenter, 443, args.username, args.password, sslContext=context)
        except IOError:
            pass
            atexit.register(Disconnect, si)

        print ("Connected to VCENTER SERVER !")

        content = si.RetrieveContent()
##        datacenter = get_obj(content, [vim.Datacenter], inputs['datacenter'])
##        cluster = get_obj(content, [vim.ClusterComputeResource], inputs['cluster'])
##        network_folder = datacenter.networkFolder


        pg_name = []
        toCreate = {}
        for a_ in range(1,ws.max_column-2):
            col = next(iterator)
            vds = ws[col+str(7)].value
            pg_name = []
            for _ in range(43,47):
                if ws[col+str(_)].value != None:
                    pg_name.append(ws[col+str(_)].value)
            pg_name = list(set(pg_name))
            toCreate.setdefault(vds,pg_name)
        for dvs_name,pgs in toCreate.items():
            dv_switch = get_obj(content, [vim.dvs.VmwareDistributedVirtualSwitch], dvs_name)
            print("\nPortGroup creation for DVS: %s" % dvs_name)
            for item in pgs:
                dvPGSpec = createPortGroup(si, dv_switch, item)
                print( dv_switch, item)
                time.sleep(5)
                content = si.RetrieveContent()

    except vmodl.MethodFault:
        print ("Caught vmodl fault: %s" % vmodl.MethodFault)
        pass
##        return 1
    except CustomException as e :
        print ("Caught exception: %s" % e)
        pass
##        return 1

# Start program
if __name__ == "__main__":
    main()