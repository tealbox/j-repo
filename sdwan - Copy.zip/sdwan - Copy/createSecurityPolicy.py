#-------------------------------------------------------------------------------
# Author:      ashok.chauhan
# File:        createSecurityPolicy.py
#-------------------------------------------------------------------------------
from sdwan import *
from sdwan_utils.utils import *
from sdwan_utils.payloads import *
import csv
from SecurityPolicyV3 import *

from sdwan_utils.cliOptions import *
########## End of import Section ##########
@click.command(context_settings=CONTEXT_SETTINGS)
@cliOptions
@click.option("--securitypolicyfile", '-f', prompt="Security Policy csv File", default='gs/securityPolicyfile.xlsx', required=True)
def cli(**cliArgs):
    # check file exist or not
    securitypolicyfile = cliArgs["securitypolicyfile"]
    try:
        os.lstat(securitypolicyfile)
    except FileNotFoundError as e:
        print("File not found!! %s" % securitypolicyfile)
        raise SystemExit()
##
    c90 = mySDWAN(vManage=cliArgs["vmanage"],username=cliArgs["username"], passcode=cliArgs["password"])
    payload = createSecurityPolicy(c90, securityGS=securitypolicyfile)
    res = c90.post(api='/template/policy/security', payload=payload)
##    print(type(res), res)
    if res == b'':
        print("created Security Policytemplate....")

if __name__ == "__main__":
    cli()