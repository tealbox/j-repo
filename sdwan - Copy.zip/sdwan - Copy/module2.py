from myXLS import *
from pathlib import Path
from pprint import pprint

_ = Path(".")
gs = _ / "gs/SP.xlsx"


status, data = fast_openpyxl(gs)
sp = data['sheet_SP']
item = sp[0]

_ = Path(".")
gs = _ / "gs/SP.xlsx"


status, data = fast_openpyxl(gs)
sp = data['sheet_SP']
item = sp[0]

def zoneBasedFWSorted(sp):
    fwGrp = {}

    for item in sp:
        name = item["zonebasedfwName"]
        l = []
        for item2 in sp:
            if item2['zonebasedfwName'] == name:
                l.append(item2)
        l = sorted(l, key=lambda i: i['position'])
        fwGrp.setdefault(name, l)
    return fwGrp

##    ##print(fwGrp)
##    for item1 in fwGrp:
##    ##    print(item)
##        for item2 in fwGrp[item1]:
##            print(item2['zonebasedfwName'], item2['position'],)
##    print("-"*40)

sp =  zoneBasedFWSorted(sp)
# dict_keys(['zonebasedfwName', 'zonebasedfwDesc', 'sourceZone', 'destinationZone', 'sourceDataPrefixList', 'destinationDataPrefixList', 'baseAction', 'log', 'sourcePortList', 'sourceport', 'destinationPortList', 'destionationport', 'portocol', 'name', 'position', 'Branch', 'AutomationAction'])

for item1 in sp:
    fwName = sp[item1][0]

    for item2 in sp[item1]:
        print(item2['zonebasedfwName'], item2['position'],)