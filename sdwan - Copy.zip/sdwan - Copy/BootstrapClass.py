import http.client
import json

def transformLower(data, key):
    # data must be a list of dict
    if (not isinstance(data,(list,))) and len(data) == 0 and key not in data[0]:
        print("Data must be list of dict and atlead one item")
        return None
    temp = {}
    for item in data:
        temp.setdefault(item[key].lower(), item)
    return temp

def validateCred(cred: str):
    if len(cred) < 5:
        print("Invalid username/password, Must be 5 or more characters")
        print("Exiting.... Please correct and re-run again")
        raise SystemExit()
    else:
        return True

class Bootstrap:
    def __init__(self,vManage, username="svc_api_automation", password=""):
        import ssl
        try:
            _create_unverified_https_context = ssl._create_unverified_context
        except AttributeError:
            # Legacy Python that doesn't verify HTTPS certificates by default
            pass
        else:
            # Handle target environment that doesn't support HTTPS verification
            ssl._create_default_https_context = _create_unverified_https_context

        # check username & password
        if validateCred(username) and validateCred(password):
            self.username = username
            self.__password = password
            __payload = f'j_username={self.username}&j_password={self.__password}'
        self.headers = {
          "Content-Type": "application/x-www-form-urlencoded",
          "Accept": "application/json"
        }
        self.baseUrl = f"https://{vManage}/dataservice"
        loginAPI = f"https://{vManage}/j_security_check"
        self.host = vManage
        self.conn = http.client.HTTPSConnection(self.host, timeout=10)
        ## check if connection is established?

        self.conn.request("POST", loginAPI, body=__payload, headers = self.headers)
        res = self.conn.getresponse()
        if res.status >= 200 and res.status <= 299:
##            data = res.read()
            cookies = res.getheader('set-cookie')
            self.headers = {'Content-Type': "application/json",'Cookie': cookies.split(";")[0]}
            print(self.headers)
##        if res.content != b'':
##            print ("Authentication fail Please check username/password!")
##            exit()
##

##            token_url=f"/dataservice/client/token"
##            headers = {
##              'Accept': 'application/json',
##              'Cookie': 'JSESSIONID=j5hCLYPP0K2V83ijzEenndHiZaj4lVd89eorFMYW.dfa48eb3-9e5b-4bca-a25a-2aace87fdf62'
##            }
##            payload = ''
##            self.conn.request("GET", "/dataservice/client/token", payload, headers)
##            res = self.conn.getresponse()
##            data = res.read()
##            print(data.decode("utf-8"))
##            self.headers.setdefault("X-XSRF-TOKEN", res.content)
##            print(token2)
            payload = ''
            headers = {
              'Accept': 'application/json',
              'Cookie': 'JSESSIONID=j5hCLYPP0K2V83ijzEenndHiZaj4lVd89eorFMYW.dfa48eb3-9e5b-4bca-a25a-2aace87fdf62'
            }
            self.conn.request("GET", "/dataservice/client/token", payload, headers)
            res = self.conn.getresponse()
            data = res.read()
            print(data.decode("utf-8"))


        #################### Pull all objects of given type ########################


    def do(self, method="GET", api="", body="", name=None):
        if method == "GET":
            self.conn.request(method, api, headers = self.headers)
        if method == "POST":
            self.conn.request(method, api, body=body, headers = self.headers)
            print("In the Do POST")
        res = self.conn.getresponse()
        if res.status >= 200 and res.status <= 299:
            data = res.read()
            _ = json.loads (data.decode("utf-8"))
            if "data" in _:
                return _["data"]
            else:
                return _

b90 = Bootstrap("10.10.20.90",username="admin", password="C1sco12345")
