import click
from sdwan import *
from hc_SearchClass import *
from tabulate import tabulate
CONTEXT_SETTINGS = dict(token_normalize_func=lambda x: x.lower())
@click.command(context_settings=CONTEXT_SETTINGS)
@click.option("--vmanage",  '-v', prompt="vManage IP", default='44.240.148.173', required=True)
@click.option("--username", '-u', prompt="vManage Username", default='svc_api_automation', required=True)
@click.option("--password", '-p', prompt="Password", hide_input=True, required=True)
@click.option("--template", '-t', prompt="Template Name/ID", required=True)
def cli(vmanage, username, password, template):
    c90 = mySDWAN(vManage=vmanage,username=username, passcode=password)
    hcs = hcSearch(vManage=vmanage,headers=c90.headers)
    allDT = hcs.getTemplates()
    _template = template.lower()
    if _template in allDT:
        templateId =  allDT[_template]['templateId']
    else:
        click.echo("%s not found, Please check Template name & run again" % template)
        raise SystemExit()
    rawData = c90.getTemplateCSV(templateId)

    rawData = rawData.get('header').get('columns')
    if rawData != None:
        with open(f"{template}_ToBeFilled.csv","w") as f:
            for item in rawData:
                f.write(item['property'])
                f.write(',')
##                print(item['property'])

if __name__ == "__main__":
    cli()