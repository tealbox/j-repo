#-------------------------------------------------------------------------------
# Author:      ashok.chauhan
# File:        createCiscoVPN.py
#-------------------------------------------------------------------------------
from sdwan import *
from sdwan_utils.utils import *
from sdwan_utils.payloads import *
import csv

from sdwan_utils.cliOptions import *
########## End of import Section ##########
@click.command(context_settings=CONTEXT_SETTINGS)
@cliOptions
@click.option("--servicevpnfile", '-s', prompt="Service VPN csv File", default='gs/serviceCiscoVPN.csv', required=True)
def cli(**cliArgs):

    servicevpnfile = cliArgs['servicevpnfile']
    try:
        os.lstat(servicevpnfile)
    except FileNotFoundError as e:
        print("File not found!! %s" % servicevpnfile)
        raise SystemExit()
##
    c90 = mySDWAN(vManage=cliArgs["vmanage"],username=cliArgs["username"], passcode=cliArgs["password"])
##    srch = hcSearch(vManage=vmanage,headers=c90.headers)

    allRecords = []

    with open(servicevpnfile, "r", encoding='utf-8-sig') as f:
        for item in csv.DictReader(f):
            allRecords.append(item)

##    print(allRecords)
    for item in allRecords:
        api = '/template/feature'
        payload = createVPNPayload(item["templateName"], item['vpn'], templateDescription=item["templateDescription"])
        print(payload)
        res = c90.post(api=api,payload=payload)
##        print(type(res), res)
        if 'templateId' in res:
            print("created Feature Template: %s, templateId: %s" % (item["templateName"], res['templateId']))


if __name__ == "__main__":
    cli()