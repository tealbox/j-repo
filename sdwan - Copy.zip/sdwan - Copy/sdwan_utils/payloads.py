import json

def createVPNInterfacePayload(templateName, templateDescription=None, ifName=None, interfaceDescription=None, interfaceIPV4Name=None, dhcpHelper=None):
    if not dhcpHelper or dhcpHelper=='None':
        dhcpHelper = {'vipObjectType': 'list','vipType': 'ignore','vipVariableName': 'vpn_if_dhcp_helper'}
    else: # for dual dhcpHelper IP address
        if isinstance(dhcpHelper, (str,)):
            dHelper = [f"{i}" for i in dhcpHelper.split(",")]

            dhcpHelper = {
              "vipObjectType": "list",
              "vipType": "constant",
              "vipValue": dHelper,
              "vipVariableName": "vpn_if_dhcp_helper"
            }
    payload = \
        {
            "deviceType": [
                "vedge-C8000V"
            ],
            "templateType": "cisco_vpn_interface",
            "templateMinVersion": "15.0.0",
            "gTemplateClass": "cedge",
            "templateDefinition": {
                "if-name": {
                    "vipObjectType": "object",
                    "vipType": "constant",
                    "vipValue": ifName,
                    "vipVariableName": 'vpn_if_name'
                },
                "description": {
                    "vipObjectType": "object",
                    "vipType": "constant",
                    "vipValue": interfaceDescription,
                    "vipVariableName": "vpn_if_description"
                },
                "ip": {
                    "address": {
                    "vipObjectType": "object",
                    "vipType": "variableName",
                    "vipValue": "",
                    "vipVariableName": interfaceIPV4Name
                    },
                    "secondary-address": {
                        "vipType": "ignore",
                        "vipValue": [],
                        "vipObjectType": "tree",
                        "vipPrimaryKey": [
                            "address"
                        ]
                    }
                },
                "dhcp-helper": {
                    "vipObjectType": "list",
                    "vipType": "ignore",
                    "vipVariableName": "vpn_if_dhcp_helper"
                },
                "mtu": {
                    "vipObjectType": "object",
                    "vipType": "ignore",
                    "vipValue": 1500,
                    "vipVariableName": "vpn_if_ip_mtu"
                },
                "tcp-mss-adjust": {
                    "vipObjectType": "object",
                    "vipType": "ignore",
                    "vipVariableName": "vpn_if_tcp_mss_adjust"
                },
                "mac-address": {
                    "vipObjectType": "object",
                    "vipType": "ignore",
                    "vipVariableName": "vpn_if_mac_address"
                },
                "speed": {
                    "vipObjectType": "object",
                    "vipType": "ignore",
                    "vipValue": "_empty",
                    "vipVariableName": "vpn_if_speed"
                },
                "duplex": {
                    "vipObjectType": "object",
                    "vipType": "ignore",
                    "vipValue": "_empty",
                    "vipVariableName": "vpn_if_duplex"
                },
                "shutdown": {
                    "vipObjectType": "object",
                    "vipType": "ignore",
                    "vipValue": "true",
                    "vipVariableName": "vpn_if_shutdown"
                },
                "arp-timeout": {
                    "vipObjectType": "object",
                    "vipType": "ignore",
                    "vipValue": 1200,
                    "vipVariableName": "vpn_if_arp_timeout"
                },
                "autonegotiate": {
                    "vipObjectType": "object",
                    "vipType": "ignore",
                    "vipVariableName": "vpn_if_autonegotiate"
                },
                "shaping-rate": {
                    "vipObjectType": "object",
                    "vipType": "ignore",
                    "vipVariableName": "rewrite_shaping_rate"
                },
                "qos-map": {
                    "vipObjectType": "object",
                    "vipType": "ignore",
                    "vipVariableName": "qos_map"
                },
                "qos-map-vpn": {
                    "vipObjectType": "object",
                    "vipType": "ignore",
                    "vipVariableName": "vpn-qos_map"
                },
                "tracker": {
                    "vipObjectType": "list",
                    "vipType": "ignore",
                    "vipVariableName": "vpn_if_tracker"
                },
                "bandwidth-upstream": {
                    "vipObjectType": "object",
                    "vipType": "ignore",
                    "vipVariableName": "vpn_if_bandwidth_upstream"
                },
                "bandwidth-downstream": {
                    "vipObjectType": "object",
                    "vipType": "ignore",
                    "vipVariableName": "vpn_if_bandwidth_downstream"
                },
                "block-non-source-ip": {
                    "vipObjectType": "object",
                    "vipType": "ignore",
                    "vipValue": "false",
                    "vipVariableName": "vpn_if_block_non_source_ip"
                },
                "rewrite-rule": {
                    "rule-name": {
                        "vipObjectType": "object",
                        "vipType": "ignore",
                        "vipVariableName": "rewrite_rule_name"
                    }
                },
                "tloc-extension": {
                    "vipObjectType": "object",
                    "vipType": "ignore",
                    "vipVariableName": "vpn_if_tloc_extension"
                },
                "load-interval": {
                    "vipObjectType": "object",
                    "vipType": "ignore",
                    "vipValue": 30,
                    "vipVariableName": "vpn_if_load_interval"
                },
                "icmp-redirect-disable": {
                    "vipObjectType": "object",
                    "vipType": "ignore",
                    "vipValue": "true",
                    "vipVariableName": "vpn_if_icmp_redirect_disable"
                },
                "tloc-extension-gre-from": {
                    "src-ip": {
                        "vipObjectType": "object",
                        "vipType": "ignore",
                        "vipVariableName": "vpn_if_tloc-ext_gre_from_src_ip"
                    },
                    "xconnect": {
                        "vipObjectType": "object",
                        "vipType": "ignore",
                        "vipVariableName": "vpn_if_tloc-ext_gre_from_xconnect"
                    }
                },
                "access-list": {
                    "vipType": "ignore",
                    "vipValue": [],
                    "vipObjectType": "tree",
                    "vipPrimaryKey": [
                        "direction"
                    ]
                },
                "auto-bandwidth-detect": {
                    "vipObjectType": "object",
                    "vipType": "ignore",
                    "vipValue": "false",
                    "vipVariableName": "vpn_if_auto_bandwidth_detect"
                },
                "iperf-server": {
                    "vipObjectType": "object",
                    "vipType": "ignore"
                },
                "media-type": {
                    "vipObjectType": "object",
                    "vipType": "ignore",
                    "vipValue": "_empty",
                    "vipVariableName": "vpn_if_media-type"
                },
                "intrf-mtu": {
                    "vipObjectType": "object",
                    "vipType": "ignore",
                    "vipValue": 1500
                },
                "ip-directed-broadcast": {
                    "vipObjectType": "object",
                    "vipType": "ignore",
                    "vipValue": "false",
                    "vipVariableName": "vpn_if_ip-directed-broadcast"
                },
                "service-provider": {
                    "vipObjectType": "object",
                    "vipType": "ignore",
                    "vipVariableName": "vpn_if_service_provider"
                },
                "trustsec": {
                    "enforcement": {
                        "enable": {
                            "vipObjectType": "object",
                            "vipType": "ignore"
                        },
                        "sgt": {
                            "vipObjectType": "object",
                            "vipType": "ignore",
                            "vipVariableName": "trusted_enforcement_sgt"
                        }
                    }
                },
                "ipv6": {
                    "access-list": {
                        "vipType": "ignore",
                        "vipValue": [],
                        "vipObjectType": "tree",
                        "vipPrimaryKey": [
                            "direction"
                        ]
                    },
                    "address": {
                        "vipObjectType": "object",
                        "vipType": "ignore",
                        "vipValue": "",
                        "vipVariableName": "vpn_if_ipv6_ipv6_address"
                    },
                    "dhcp-helper-v6": {
                        "vipType": "ignore",
                        "vipValue": [],
                        "vipObjectType": "tree",
                        "vipPrimaryKey": [
                            "address"
                        ]
                    },
                    "secondary-address": {
                        "vipType": "ignore",
                        "vipValue": [],
                        "vipObjectType": "tree",
                        "vipPrimaryKey": [
                            "address"
                        ]
                    }
                },
                "arp": {
                    "ip": {
                        "vipType": "ignore",
                        "vipValue": [],
                        "vipObjectType": "tree",
                        "vipPrimaryKey": [
                            "addr"
                        ]
                    }
                },
                "vrrp": {
                    "vipType": "ignore",
                    "vipValue": [],
                    "vipObjectType": "tree",
                    "vipPrimaryKey": [
                        "grp-id"
                    ]
                },
                "ipv6-vrrp": {
                    "vipType": "ignore",
                    "vipValue": [],
                    "vipObjectType": "tree",
                    "vipPrimaryKey": [
                        "grp-id"
                    ]
                }
            },
            "factoryDefault": False,
            "feature": "vmanage-default",
            "templateName": templateName,
            "templateDescription": templateDescription
        }

    payload['templateDefinition'].setdefault("dhcp-helper", dhcpHelper)
    return json.dumps(payload)











##def createVPNInterfacePayload(templateName, templateDescription=None, ifName=None, interfaceDescription=None, dhcpHelper=None):
##    if not dhcpHelper or dhcpHelper=='None':
##        dhcpHelper = {'vipObjectType': 'list','vipType': 'ignore','vipVariableName': 'vpn_if_dhcp_helper'}
##    else: # for dual dhcpHelper IP address
##        if isinstance(dhcpHelper, (str,)):
##            dHelper = [f"{i}" for i in dhcpHelper.split(",")]
##
##            dhcpHelper = {
##              "vipObjectType": "list",
##              "vipType": "constant",
##              "vipValue": dHelper,
##              "vipVariableName": "vpn_if_dhcp_helper"
##            }
##    payload = \
##        {'deviceType': ['vedge-C8000V'],
##         'factoryDefault': False,
##         'templateDefinition': {'access-list': {'vipObjectType': 'tree',
##                                                'vipPrimaryKey': ['direction'],
##                                                'vipType': 'ignore',
##                                                'vipValue': []},
##                                'arp': {'ip': {'vipObjectType': 'tree',
##                                               'vipPrimaryKey': ['addr'],
##                                               'vipType': 'ignore',
##                                               'vipValue': []}},
##                                'arp-timeout': {'vipObjectType': 'object',
##                                                'vipType': 'ignore',
##                                                'vipValue': 1200,
##                                                'vipVariableName': 'vpn_if_arp_timeout'},
##                                'autonegotiate': {'vipObjectType': 'object',
##                                                  'vipType': 'ignore',
##                                                  'vipValue': 'true',
##                                                  'vipVariableName': 'vpn_if_autonegotiate'},
##                                'bandwidth-downstream': {'vipObjectType': 'object',
##                                                         'vipType': 'ignore',
##                                                         'vipVariableName': 'vpn_if_bandwidth_downstream'},
##                                'bandwidth-upstream': {'vipObjectType': 'object',
##                                                       'vipType': 'ignore',
##                                                       'vipVariableName': 'vpn_if_bandwidth_upstream'},
##                                'block-non-source-ip': {'vipObjectType': 'object',
##                                                        'vipType': 'ignore',
##                                                        'vipValue': 'false',
##                                                        'vipVariableName': 'vpn_if_block_non_source_ip'},
##                                'clear-dont-fragment': {'vipObjectType': 'object',
##                                                        'vipType': 'ignore',
##                                                        'vipValue': 'false',
##                                                        'vipVariableName': 'vpn_if_clear_dont_fragment'},
##                                'description': {'vipObjectType': 'object',
##                                                'vipType': 'constant',
##                                                'vipValue': interfaceDescription,
##                                                'vipVariableName': 'vpn_if_description'},
##                                'dot1x': {'vipObjectType': 'node-only',
##                                          'vipType': 'ignore'},
##                                'duplex': {'vipObjectType': 'object',
##                                           'vipType': 'ignore',
##                                           'vipValue': '_empty',
##                                           'vipVariableName': 'vpn_if_duplex'},
##                                'flow-control': {'vipObjectType': 'object',
##                                                 'vipType': 'ignore',
##                                                 'vipValue': 'autoneg',
##                                                 'vipVariableName': 'vpn_if_flow_control'},
##                                'icmp-redirect-disable': {'vipObjectType': 'object',
##                                                          'vipType': 'ignore',
##                                                          'vipValue': 'false',
##                                                          'vipVariableName': 'vpn_if_icmp_redirect_disable'},
##                                'if-name': {'vipObjectType': 'object',
##                                            'vipType': 'constant',
##                                            'vipValue': ifName,
##                                            'vipVariableName': 'vpn_if_name'},
##                                'ip': {'address': {'vipObjectType': 'object',
##                                                   'vipType': 'ignore',
##                                                   'vipVariableName': 'vpn_if_ipv4_address'},
##                                       'secondary-address': {'vipObjectType': 'tree',
##                                                             'vipPrimaryKey': ['address'],
##                                                             'vipType': 'ignore',
##                                                             'vipValue': []}},
##                                'ip-directed-broadcast': {'vipObjectType': 'object',
##                                                          'vipType': 'ignore',
##                                                          'vipValue': 'false',
##                                                          'vipVariableName': 'vpn_if_ip-directed-broadcast'},
##                                'ipv6': {'access-list': {'vipObjectType': 'tree',
##                                                         'vipPrimaryKey': ['direction'],
##                                                         'vipType': 'ignore',
##                                                         'vipValue': []},
##                                         'address': {'vipObjectType': 'object',
##                                                     'vipType': 'ignore',
##                                                     'vipValue': '',
##                                                     'vipVariableName': 'vpn_if_ipv6_ipv6_address'},
##                                         'dhcp-helper-v6': {'vipObjectType': 'tree',
##                                                            'vipPrimaryKey': ['address'],
##                                                            'vipType': 'ignore',
##                                                            'vipValue': []},
##                                         'ipv6-shutdown': {'vipObjectType': 'object',
##                                                           'vipType': 'ignore',
##                                                           'vipValue': 'false',
##                                                           'vipVariableName': 'vpn_if_ipv6_ipv6_shutdown'},
##                                         'secondary-address': {'vipObjectType': 'tree',
##                                                               'vipPrimaryKey': ['address'],
##                                                               'vipType': 'ignore',
##                                                               'vipValue': []}},
##                                'ipv6-vrrp': {'vipObjectType': 'tree',
##                                              'vipPrimaryKey': ['grp-id'],
##                                              'vipType': 'ignore',
##                                              'vipValue': []},
##                                'mac-address': {'vipObjectType': 'object',
##                                                'vipType': 'ignore',
##                                                'vipVariableName': 'vpn_if_mac_address'},
##                                'mtu': {'vipObjectType': 'object',
##                                        'vipType': 'ignore',
##                                        'vipValue': 1500,
##                                        'vipVariableName': 'vpn_if_ip_mtu'},
##                                'pmtu': {'vipObjectType': 'object',
##                                         'vipType': 'ignore',
##                                         'vipValue': 'false',
##                                         'vipVariableName': 'vpn_if_pmtu'},
##                                'policer': {'vipObjectType': 'tree',
##                                            'vipPrimaryKey': ['policer-name',
##                                                              'direction'],
##                                            'vipType': 'ignore',
##                                            'vipValue': []},
##                                'qos-map': {'vipObjectType': 'object',
##                                            'vipType': 'ignore',
##                                            'vipVariableName': 'qos_map'},
##                                'rewrite-rule': {'rule-name': {'vipObjectType': 'object',
##                                                               'vipType': 'ignore',
##                                                               'vipVariableName': 'rewrite_rule_name'}},
##                                'shaping-rate': {'vipObjectType': 'object',
##                                                 'vipType': 'ignore',
##                                                 'vipVariableName': 'qos_shaping_rate'},
##                                'shutdown': {'vipObjectType': 'object',
##                                             'vipType': 'ignore',
##                                             'vipValue': 'true',
##                                             'vipVariableName': 'vpn_if_shutdown'},
##                                'speed': {'vipObjectType': 'object',
##                                          'vipType': 'ignore',
##                                          'vipValue': '_empty',
##                                          'vipVariableName': 'vpn_if_speed'},
##                                'static-ingress-qos': {'vipObjectType': 'object',
##                                                       'vipType': 'ignore',
##                                                       'vipVariableName': 'vpn_if_static_ingress_qos'},
##                                'tcp-mss-adjust': {'vipObjectType': 'object',
##                                                   'vipType': 'ignore',
##                                                   'vipVariableName': 'vpn_if_tcp_mss_adjust'},
##                                'tloc-extension': {'vipObjectType': 'object',
##                                                   'vipType': 'ignore',
##                                                   'vipVariableName': 'vpn_if_tloc_extension'},
##                                'tloc-extension-gre-from': {'src-ip': {'vipObjectType': 'object',
##                                                                       'vipType': 'ignore',
##                                                                       'vipVariableName': 'vpn_if_tloc-ext_gre_from_src_ip'},
##                                                            'xconnect': {'vipObjectType': 'object',
##                                                                         'vipType': 'ignore',
##                                                                         'vipVariableName': 'vpn_if_tloc-ext_gre_from_xconnect'}},
##                                'tracker': {'vipObjectType': 'list',
##                                            'vipType': 'ignore',
##                                            'vipVariableName': 'vpn_if_tracker'},
##                                'vrrp': {'vipObjectType': 'tree',
##                                         'vipPrimaryKey': ['grp-id'],
##                                         'vipType': 'ignore',
##                                         'vipValue': []}},
##         'templateDescription': templateDescription,
##         'templateMinVersion': '15.0.0',
##         'templateName': templateName,
##         'templateType': 'cisco_vpn_interface'}
##
##    payload['templateDefinition'].setdefault("dhcp-helper", dhcpHelper)
##    return json.dumps(payload)

## print(createVPNInterfacePayload("FT_Global_BR_INTF_GE3.600_v1", templateDescription="FT_Global_BR_INTF_GE3.600_v1 Template",
##    ifName="GigabitEthernet3.600", interfaceDescription="GigabitEthernet3.600 Branch-III", dhcpHelper="10.131.118.203,10.131.118.189"))


def createVPNPayload(templateName, vpn_id, templateDescription=None):
    if vpn_id.isnumeric():
        vpn_id = int(vpn_id)
    else:
        print("Invalid VPN ID: %s, correct and run again" % vpn_id)
        raise SystemExit()
    return json.dumps(\
    {'deviceType': ['vedge-C8000V'],
     'factoryDefault': False,
     'templateDefinition': {'ecmp-hash-key': {'layer4': {'vipObjectType': 'object',
                                                         'vipType': 'ignore',
                                                         'vipValue': 'false',
                                                         'vipVariableName': 'vpn_layer4'}},
                            'host': {'vipObjectType': 'tree',
                                     'vipPrimaryKey': ['hostname'],
                                     'vipType': 'ignore',
                                     'vipValue': []},
                            'ip': {'gre-route': {},
                                   'ipsec-route': {},
                                   'service-route': {}},
                            'ipv6': {},
                            'name': {'vipObjectType': 'object',
                                     'vipType': 'constant',
                                     'vipValue': 'Branch_VPN_300_Template',
                                     'vipVariableName': 'vpn_name'},
                            'nat64': {'v4': {'pool': {'vipObjectType': 'tree',
                                                      'vipPrimaryKey': ['name'],
                                                      'vipType': 'ignore',
                                                      'vipValue': []}}},
                            'nat64-global': {'prefix': {'stateful': {}}},
                            'omp': {'advertise': {'vipObjectType': 'tree',
                                                  'vipPrimaryKey': ['protocol'],
                                                  'vipType': 'ignore',
                                                  'vipValue': []},
                                    'distance': {'vipObjectType': 'object',
                                                 'vipType': 'ignore',
                                                 'vipValue': '',
                                                 'vipVariableName': 'vpn_distance'},
                                    'ipv6-advertise': {'vipObjectType': 'tree',
                                                       'vipPrimaryKey': ['protocol'],
                                                       'vipType': 'ignore',
                                                       'vipValue': []}},
                            'route-export': {'vipObjectType': 'tree',
                                             'vipPrimaryKey': ['protocol'],
                                             'vipType': 'ignore',
                                             'vipValue': []},
                            'route-import': {'vipObjectType': 'tree',
                                             'vipPrimaryKey': ['protocol'],
                                             'vipType': 'ignore',
                                             'vipValue': []},
                            'route-import-service': {'from': {'vipObjectType': 'tree',
                                                              'vipPrimaryKey': ['vpn',
                                                                                'protocol'],
                                                              'vipType': 'ignore',
                                                              'vipValue': []}},
                            'service': {'vipObjectType': 'tree',
                                        'vipPrimaryKey': ['svc-type'],
                                        'vipType': 'ignore',
                                        'vipValue': []},
                            'tcp-optimization': {'vipObjectType': 'node-only',
                                                 'vipType': 'ignore',
                                                 'vipValue': 'false',
                                                 'vipVariableName': 'vpn_tcp_optimization'},
                            'vpn-id': {'vipObjectType': 'object',
                                       'vipType': 'constant',
                                       'vipValue': vpn_id}},
     'templateDescription': templateDescription,
     'templateMinVersion': '15.0.0',
     'templateName': templateName,
     # 'templateType': 'vpn-vedge',
     'templateType': 'cisco_vpn'}
        )

