import click
import os, csv
from sdwan import *
from hc_SearchClass import *
from tabulate import tabulate
from sdwan_utils.utils import *
from zoneBasedFW_v1 import *


def zoneBasedFWSorted(sp):
    fwGrp = {}

    for item in sp:
        name = item["zonebasedfwName"]
        l = []
        for item2 in sp:
            if item2['zonebasedfwName'] == name:
                l.append(item2)
        l = sorted(l, key=lambda i: i['position'])
        fwGrp.setdefault(name, l)
    return fwGrp
    ##    ##print(fwGrp)
    ##    for item1 in fwGrp:
    ##    ##    print(item)
    ##        for item2 in fwGrp[item1]:
    ##            print(item2['zonebasedfwName'], item2['position'],)
    ##    print("-"*40)


from sdwan_utils.cliOptions import *
########## End of import Section ##########
@click.command(context_settings=CONTEXT_SETTINGS)
@cliOptions
@click.option("--zonebasedfwfile", '-z', prompt="ZoneBasedFW File", default='gs/zoneBasedFWFile.csv', required=True)
def cli(**cliArgs):
    zonebasedfwfile = cliArgs["zonebasedfwfile"]
    # check file exist or not
    try:
        os.lstat(zonebasedfwfile)
    except FileNotFoundError as e:
        print("File not found!! %s" % zonebasedfwfile)
        raise SystemExit()
##
    c90 = mySDWAN(vManage=cliArgs["vmanage"],username=cliArgs["username"], passcode=cliArgs["password"])
    srch = hcSearch(vManage=cliArgs["vmanage"], headers=c90.headers)

    zbFWData = []
    with open(zonebasedfwfile, "r", encoding='utf-8-sig') as f:
        for item in csv.DictReader(f):
            zbFWData.append(item)

    ##_ = Path(".")
    ##gs = _ / "gs/SP.xlsx"
    ##
    ##
    ##status, data = fast_openpyxl(gs)
    ##zbFWData = data['sheet_SP']
    ##item = zbFWData[0]



    zbFWData = zoneBasedFWSorted(zbFWData)

    # dict_keys(['zonebasedfwName', 'zonebasedfwDesc', 'sourceZone', 'destinationZone', 'sourceDataPrefixList', 'destinationDataPrefixList', 'baseAction', 'log', 'sourcePortList', 'sourceport', 'destinationPortList', 'destionationport', 'portocol', 'name', 'position', 'Branch', 'AutomationAction'])

    for fwItem in zbFWData:
        fwName = zbFWData[fwItem][0]
        zonebasedfwName = fwName['zonebasedfwName']
        status = srch.getId(objType='zonebasedfw', name=zonebasedfwName)
    ##    print(status)
        if status != "ZoneBasedFWNotFound":
            print("ZoneBasedFW %s is already exist, Status: %s" % (zonebasedfwName,status))
            continue

        sourceZoneId = srch.getId(objType='zone', name=fwName['sourceZone'])
        destinationZoneId = srch.getId(objType='zone', name=fwName['destinationZone'])

        cZoneBasedFW = ZoneBasedFW(zoneBasedFWname =fwName['zonebasedfwName'],zoneBasedFWdescription=fwName["zonebasedfwDesc"],defaultAction="log",
                sourceZoneId=sourceZoneId, destinationZoneId=destinationZoneId)
        for item in zbFWData[fwItem]:
            # print(item['zonebasedfwName'], item['position'],)
            # create Rule
            cZoneBasedFW.createSequenceRule(int(item['position']),item['name'],item['baseAction'].lower())

            sList = item['sourceDataPrefixList'].lower()
            if sList != 'any':
                sRef = srch.getId(objType='dataprefix', name=sList)
                cZoneBasedFW.createSequence("sourceDataPrefixList", sRef)
                # add only when we don;t have any
                cZoneBasedFW.addSequence2Rule()

            dList = item['destinationDataPrefixList'].lower()
            if dList != 'any':
                dRef = srch.getId(objType='dataprefix', name=dList)
                cZoneBasedFW.createSequence("destinationDataPrefixList", dRef)
                # add only when we don;t have any
                cZoneBasedFW.addSequence2Rule()

            sPortList = item['sourcePort'].lower()
            if sPortList != 'any':
                # check if int
                if sPortList.isdigit():
                    # convert to number
                    cZoneBasedFW.createValueSequence("sourcePort", sPortList)
                    cZoneBasedFW.addSequence2Rule()
                else:
                    dRef = srch.getId(objType='port', name=sPortList)
                    cZoneBasedFW.createSequence("sourcePortList", dRef)
                    # add only when we don;t have any
                    cZoneBasedFW.addSequence2Rule()

            dPortList = item['destionationPort'].lower()
            if dPortList != 'any':
                # check if int
                if dPortList.isdigit():
                    # convert to number
                    cZoneBasedFW.createValueSequence("destinationPort", dPortList)
                    cZoneBasedFW.addSequence2Rule()
                else:
                    dRef = srch.getId(objType='port', name=dPortList)
                    cZoneBasedFW.createSequence("destinationPortList", dRef)
                    # add only when we don;t have any
                    cZoneBasedFW.addSequence2Rule()

            cZoneBasedFW.addSequenceRule2zoneBasedFW()

    ##    print(json.dumps( cZoneBasedFW.zoneBasedFW, indent=2))
        c90.post(api='/template/policy/definition/zonebasedfw', method='POST', payload=json.dumps( cZoneBasedFW.zoneBasedFW), name=zonebasedfwName)


if __name__ == "__main__":
    cli()