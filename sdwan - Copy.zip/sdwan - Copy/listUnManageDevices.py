######## import modules ########
import click
from sdwan import *
from tabulate import tabulate
from sdwan_utils.cliOptions import *
########## End of import Section ##########
@click.command(context_settings=CONTEXT_SETTINGS)
@cliOptions
def cli(**cliArgs):
    c90 = mySDWAN(vManage=cliArgs["vmanage"],username=cliArgs["username"], passcode=cliArgs["password"])
    cEdges = c90.getVedges()
    cEdgesList = []
    for item in cEdges:
        if item['managed-by'] == 'Unmanaged':
            cEdgesList.append([item['chasisNumber'], item['uuid'], item['serialNumber'], item['deviceState'], item['managed-by']])
    print( tabulate(cEdgesList, headers=['chasisNumber', 'uuid', 'serialNumber','deviceState', 'managed-by']))
if __name__ == "__main__":
    cli()