import click
from sdwan_utils.cliOptions import *
from sdwan_utils.myCSV import *
from sdwan import *
import time
# templateId, deviceCSV
@click.command(context_settings=CONTEXT_SETTINGS)
def cli(**cliArgs):
##    print(cliArgs["vmanage"],cliArgs["username"],cliArgs["password"],cliArgs["portfile"])
    c90 = mySDWAN(vManage="10.10.20.90",username="admin", passcode="C1sco12345")
    d = c90.get(api='/template/device')
    w= transform(d['data'],'templateName')
    templatename = "Site1-cEdge01"
##    print(w)
    print(w[templatename]['templateId'], "\t", w[templatename]['templateName'] )

if __name__ == "__main__":
    cli()