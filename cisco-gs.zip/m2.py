import re

# Input text
text = """
Cisco Nexus Operating System (NX-OS) Software
TAC support: http://www.cisco.com/tac
Copyright (C) 2002-2017, Cisco and/or its affiliates.
All rights reserved.
The copyrights to certain works contained in this software are
owned by other third parties and used and distributed under their own
licenses, such as open source.  This software is provided "as is," and unless
otherwise stated, there is no warranty, express or implied, including but not
limited to warranties of merchantability and fitness for a particular purpose.
Certain components of this software are licensed under
the GNU General Public License (GPL) version 2.0 or
GNU General Public License (GPL) version 3.0  or the GNU
Lesser General Public License (LGPL) Version 2.1 or
Lesser General Public License (LGPL) Version 2.0.
A copy of each such license is available at
http://www.opensource.org/licenses/gpl-2.0.php and
http://opensource.org/licenses/gpl-3.0.html and
http://www.opensource.org/licenses/lgpl-2.1.php and
http://www.gnu.org/licenses/old-licenses/library.txt.

Software
  BIOS: version 07.66
  NXOS: version 7.0(3)I7(2)
  BIOS compile time:  06/11/2019
  NXOS image file is: bootflash:///nxos.7.0.3.I7.2.bin
  NXOS compile time:  11/22/2017 13:00:00 [11/22/2017 21:55:29]


Hardware
  cisco Nexus9000 93180YC-EX chassis
  Intel(R) Xeon(R) CPU  @ 1.80GHz with 24633476 kB of memory.
  Processor Board ID FQ024561T2Y

  Device name: switchNX01
  bootflash:   53298520 kB
Kernel uptime is 603 day(s), 21 hour(s), 57 minute(s), 32 second(s)

Last reset at 146968 usecs after Sat Sep 23 16:21:55 2023
  Reason: Reset Requested by CLI command reload
  System version: 7.0(3)I7(2)
  Service:

plugin
  Core Plugin, Ethernet Plugin

Active Package(s):
        nxos.CSCvx21260-n9k_ALL-1.0.1-7.0.3.I7.9.lib32_n9000
"""

# Function to extract sections
def extract_sections(input_text):
    # Define section names
    sections = ["Software", "Hardware", "Kernel", "Last reset", "plugin", "Active Package(s)"]
    result = {}

    # Split the text into lines
    lines = input_text.splitlines()

    # Initialize variables
    current_section = None
    section_content = []

    for line in lines:
        # Check if the line starts a new section
        if any(line.strip().startswith(section) for section in sections):
            # Save the previous section (if exists)
            if current_section:
                result[current_section] = "\n".join(section_content).strip()
            # Start a new section
            current_section = next(section for section in sections if line.strip().startswith(section))
            section_content = []
        elif line.strip() and current_section:
            # Add non-empty lines to the current section
            section_content.append(line.strip())

    # Save the last section
    if current_section:
        result[current_section] = "\n".join(section_content).strip()

    return result

# Extract and print the sections
sections = extract_sections(text)
for section_name, section_content in sections.items():
    print(f"### {section_name}\n")
    print(section_content)
    print("\n" + "-" * 40 + "\n")