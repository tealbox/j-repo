class DeviceInfo:
    def __init__(self, software, hardware, kernel, last_reset, plugin, active_package):
        self.software = software.strip()
        self.hardware = hardware.strip()
        self.kernel = kernel.strip()
        self.last_reset = last_reset.strip()
        self.plugin = plugin.strip()
        self.active_package = active_package.strip()
        # Parse the hardware into a dictionary
        self.device_software = parse_text_to_dict(self.software)

        # Transform the text
        device_hardware = transform_hardware(self.hardware)
        self.device_hardware = parse_text_to_dict(device_hardware)
        self.set_variables()

    def set_variables(self):
        self.name = self.device_hardware.get('Device name',None)
        self.chassis = self.device_hardware.get('chassis',None)
        self.processor = self.device_hardware.get('processor',None)
        self.serial = self.device_hardware.get('Processor Board ID',None)

    def display_software(self):
        print("### Software\n")
        print(self.software)
        print("\n" + "-" * 40 + "\n")

    def display_hardware(self):
        print("### Hardware\n")
        print(self.hardware)
        print("\n" + "-" * 40 + "\n")

    def display_kernel(self):
        print("### Kernel\n")
        print(self.kernel)
        print("\n" + "-" * 40 + "\n")

    def display_last_reset(self):
        print("### Last Reset\n")
        print(self.last_reset)
        print("\n" + "-" * 40 + "\n")

    def display_plugin(self):
        print("### Plugin\n")
        print(self.plugin)
        print("\n" + "-" * 40 + "\n")

    def display_active_package(self):
        print("### Active Package(s)\n")
        print(self.active_package)
        print("\n" + "-" * 40 + "\n")

    def display_all(self):
        self.display_software()
        self.display_hardware()
        self.display_kernel()
        self.display_last_reset()
        self.display_plugin()
        self.display_active_package()




def extract_sections(input_text):
    # Define section names
    sections = ["Software", "Hardware", "Kernel", "Last reset", "plugin", "Active Package(s)"]
    result = {}

    # Split the text into lines
    lines = input_text.splitlines()

    # Initialize variables
    current_section = None
    section_content = []

    for line in lines:
        # Check if the line starts a new section
        if any(line.strip().startswith(section) for section in sections):
            # Save the previous section (if exists)
            if current_section:
                result[current_section] = "\n".join(section_content).strip()
            # Start a new section
            current_section = next(section for section in sections if line.strip().startswith(section))
            section_content = []
        elif line.strip() and current_section:
            # Add non-empty lines to the current section
            section_content.append(line.strip())

    # Save the last section
    if current_section:
        result[current_section] = "\n".join(section_content).strip()

    return result


def parse_text_to_dict(text):
    # Initialize an empty dictionary to store the parsed data
    result = {}

    # Split the text into lines
    lines = text.splitlines()

    # Iterate through each line
    for line in lines:
        # Strip leading/trailing whitespace
        line = line.strip()

        # Check if the line contains a colon
        if ":" in line:
            # Split the line into key and value based on the first colon
            key, value = line.split(":", 1)

            # Strip whitespace from key and value
            key = key.strip()
            value = value.strip()

            # Add the key-value pair to the dictionary
            result[key] = value

    return result

def transform_hardware(input_text):
    # Initialize a list to store the transformed lines
    transformed_lines = []

    # Split the input text into lines
    lines = input_text.splitlines()

    for line in lines:
        line = line.strip()  # Remove leading/trailing whitespace

        if not line:  # Skip empty lines
            continue

        # Match specific patterns and add labels
        if "chassis" in line:
            transformed_lines.append(f"chassis: {line}")
        elif "Intel(R)" in line:
            transformed_lines.append(f"processor: {line}")
        # Check if the line contains "Processor Board ID"
        elif "Processor Board ID" in line:
            # Split the line into two parts: before and after "Processor Board ID"
            parts = line.split("Processor Board ID", 1)

            # Ensure there are two parts (label and value)
            if len(parts) == 2:
                key = "Processor Board ID"
                value = parts[1].strip()  # Extract the value and remove whitespace
            transformed_lines.append(f"{key.strip()}: {value.strip()}")
        elif ":" in line:
            # Preserve existing key-value pairs
            key, value = line.split(":", 1)
            transformed_lines.append(f"{key.strip()}: {value.strip()}")
        else:
            # For any other lines, append as-is
            transformed_lines.append(line)

    # Join the transformed lines into a single string
    return "\n".join(transformed_lines)

### Parse the hardware into a dictionary
##device_software = parse_text_to_dict(device_info.software)
### Transform the text
##device_hardware = transform_hardware(device_info.hardware)


# Input text
show_version = """
Cisco Nexus Operating System (NX-OS) Software
TAC support: http://www.cisco.com/tac
Copyright (C) 2002-2017, Cisco and/or its affiliates.
All rights reserved.
The copyrights to certain works contained in this software are
owned by other third parties and used and distributed under their own
licenses, such as open source.  This software is provided "as is," and unless
otherwise stated, there is no warranty, express or implied, including but not
limited to warranties of merchantability and fitness for a particular purpose.
Certain components of this software are licensed under
the GNU General Public License (GPL) version 2.0 or
GNU General Public License (GPL) version 3.0  or the GNU
Lesser General Public License (LGPL) Version 2.1 or
Lesser General Public License (LGPL) Version 2.0.
A copy of each such license is available at
http://www.opensource.org/licenses/gpl-2.0.php and
http://opensource.org/licenses/gpl-3.0.html and
http://www.opensource.org/licenses/lgpl-2.1.php and
http://www.gnu.org/licenses/old-licenses/library.txt.

Software
  BIOS: version 07.66
  NXOS: version 7.0(3)I7(2)
  BIOS compile time:  06/11/2019
  NXOS image file is: bootflash:///nxos.7.0.3.I7.2.bin
  NXOS compile time:  11/22/2017 13:00:00 [11/22/2017 21:55:29]


Hardware
  cisco Nexus9000 93180YC-EX chassis
  Intel(R) Xeon(R) CPU  @ 1.80GHz with 24633476 kB of memory.
  Processor Board ID FQ024561T2Y

  Device name: switchNX01
  bootflash:   53298520 kB
Kernel uptime is 603 day(s), 21 hour(s), 57 minute(s), 32 second(s)

Last reset at 146968 usecs after Sat Sep 23 16:21:55 2023
  Reason: Reset Requested by CLI command reload
  System version: 7.0(3)I7(2)
  Service:

plugin
  Core Plugin, Ethernet Plugin

Active Package(s):
        nxos.CSCvx21260-n9k_ALL-1.0.1-7.0.3.I7.9.lib32_n9000
"""

# Extract sections
sections = extract_sections(show_version)

# Create an instance of DeviceInfo
device_info = DeviceInfo(
    software=sections.get("Software", ""),
    hardware=sections.get("Hardware", ""),
    kernel=sections.get("Kernel", ""),
    last_reset=sections.get("Last reset", ""),
    plugin=sections.get("plugin", ""),
    active_package=sections.get("Active Package(s)", "")
)

# Display all sections
##device_info.display_all()

print(device_info.device_software)
print(device_info.device_hardware)
print(device_info.name)
print(device_info.chassis)
print(device_info.processor)
print(device_info.serial)
