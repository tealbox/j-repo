import json

data = {
    'service_entries': [
        {'_protection': 'NOT_PROTECTED', 'destination_ports': ['5671'], 'l4_protocol': 'TCP', 'marked_for_delete': False, 'overridden': False, 'resource_type': 'L4PortSetServiceEntry', 'source_ports': []},
        {'_protection': 'NOT_PROTECTED', 'destination_ports': ['5672'], 'l4_protocol': 'TCP', 'marked_for_delete': False, 'overridden': False, 'resource_type': 'L4PortSetServiceEntry', 'source_ports': []},
        {'_protection': 'NOT_PROTECTED', 'destination_ports': ['80'], 'l4_protocol': 'TCP', 'marked_for_delete': False, 'overridden': False, 'resource_type': 'L4PortSetServiceEntry', 'source_ports': []},
        {'_protection': 'NOT_PROTECTED', 'destination_ports': ['566'], 'l4_protocol': 'UDP', 'marked_for_delete': False, 'overridden': False, 'resource_type': 'L4PortSetServiceEntry', 'source_ports': []},
        {'_protection': 'NOT_PROTECTED', 'destination_ports': ['867'], 'l4_protocol': 'UDP', 'marked_for_delete': False, 'overridden': False, 'resource_type': 'L4PortSetServiceEntry', 'source_ports': []},
        {'_protection': 'NOT_PROTECTED', 'destination_ports': ['443'], 'l4_protocol': 'TCP', 'marked_for_delete': False, 'overridden': False, 'resource_type': 'L4PortSetServiceEntry', 'source_ports': []},
        {'_protection': 'NOT_PROTECTED', 'destination_ports': ['5068'], 'l4_protocol': 'UDP', 'marked_for_delete': False, 'overridden': False, 'resource_type': 'L4PortSetServiceEntry', 'source_ports': []}
    ]
}

def get_service_ports(service_entries=None):
    tcp_ports = []
    udp_ports = []

    for entry in data['service_entries']:
        if entry['l4_protocol'] == 'TCP':
            tcp_ports.append(int(entry['destination_ports'][0]))
        elif entry['l4_protocol'] == 'UDP':
            udp_ports.append(int(entry['destination_ports'][0]))
    tcp_ports = sorted(tcp_ports)
    tcp_ports.insert(0,'TCP')
    udp_ports = sorted(udp_ports)
    udp_ports.insert(0,'UDP')
    return (tcp_ports, udp_ports)




print("TCP Ports:", tcp_ports)
print("UDP Ports:", udp_ports)