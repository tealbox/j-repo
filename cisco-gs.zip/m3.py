show_ver  = """
Cisco Nexus Operating System (NX-OS) Software
TAC support: http://www.cisco.com/tac
Copyright (C) 2002-2017, Cisco and/or its affiliates.
All rights reserved.
The copyrights to certain works contained in this software are
owned by other third parties and used and distributed under their own
licenses, such as open source.  This software is provided "as is," and unless
otherwise stated, there is no warranty, express or implied, including but not
limited to warranties of merchantability and fitness for a particular purpose.
Certain components of this software are licensed under
the GNU General Public License (GPL) version 2.0 or
GNU General Public License (GPL) version 3.0  or the GNU
Lesser General Public License (LGPL) Version 2.1 or
Lesser General Public License (LGPL) Version 2.0.
A copy of each such license is available at
http://www.opensource.org/licenses/gpl-2.0.php and
http://opensource.org/licenses/gpl-3.0.html and
http://www.opensource.org/licenses/lgpl-2.1.php and
http://www.gnu.org/licenses/old-licenses/library.txt.

Software
  BIOS: version 07.66
  NXOS: version 7.0(3)I7(2)
  BIOS compile time:  06/11/2019
  NXOS image file is: bootflash:///nxos.7.0.3.I7.2.bin
  NXOS compile time:  11/22/2017 13:00:00 [11/22/2017 21:55:29]


Hardware
  cisco Nexus9000 93180YC-EX chassis
  Intel(R) Xeon(R) CPU  @ 1.80GHz with 24633476 kB of memory.
  Processor Board ID FDO24161E2G

  Device name: ks1sx052
  bootflash:   53298520 kB
Kernel uptime is 603 day(s), 21 hour(s), 57 minute(s), 32 second(s)

Last reset at 146968 usecs after Sat Sep 23 16:21:55 2023
  Reason: Reset Requested by CLI command reload
  System version: 7.0(3)I7(2)
  Service:

plugin
  Core Plugin, Ethernet Plugin
"""

print(show_ver)