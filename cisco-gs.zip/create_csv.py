import csv

# Example data: List of lists
data = [
    ["Name", "Age", "City"],  # Header row
    ["Alice", 30, "New York"],
    ["Bob", 25, "Los Angeles"],
    ["Charlie", 35, "Chicago"]
]

# Write the data to a CSV file
with open("output.csv", mode="w", newline="", encoding="utf-8") as file:
    writer = csv.writer(file)
    writer.writerows(data)  # Write all rows at once

print("CSV file created successfully!")