

import argparse
import os
import getpass

def main():
    # Set up argument parser
    parser = argparse.ArgumentParser(description="Process arguments for automation script.")

    # Add arguments
    parser.add_argument(
        "--base-dir",
        "-b",
        help="Base directory for operations. Defaults to the current working directory if not provided.",
        default=None
    )
    parser.add_argument(
        "--inventory-file",
        "-i",
        help="Path to the inventory file. In format Device Name, IP Address",
        required=True
    )
    parser.add_argument(
        "--username",
        "-u",
        help="Username for authentication.",
        required=True
    )

    # Parse known arguments (password will be handled separately)
    args = parser.parse_args()

    # If base directory is not provided, use the current working directory
    base_dir = args.base_dir if args.base_dir else os.getcwd()
    print(f"Using base directory: {base_dir}")

    # Prompt for password securely
    password = getpass.getpass(prompt="Enter password: ")

    # Display collected information (for demonstration purposes only; do not log passwords in production)
    print("\nCollected Information:")
    print(f"Base Directory: {base_dir}")
    print(f"Inventory File: {args.inventory_file}")
    print(f"Username: {args.username}")
    print("Password: [*H*i*d*d*e*n*]")  # Password is not echoed or displayed

if __name__ == "__main__":
    main()
