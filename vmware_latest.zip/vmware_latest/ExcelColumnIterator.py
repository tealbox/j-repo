##import
from pyVmomi import vim, vmodl
from pyvim import connect
from pyvim.connect import Disconnect
from ExcelColumnIterator import *
import argparse, getpass
import ssl, re
context = ssl.create_default_context()
context.check_hostname = False
context.verify_mode = ssl.CERT_NONE
class ExcelColumnIterator:
    def __init__(self,num=1):
        if isinstance(num,int):
            self.column_number = num
        elif isinstance(num,str) and len(num)==1:
            self.column_number = ord(num.upper()) - 64
        else:
            raise SystemExit("num must be integer or single character[a-z]")


    def __iter__(self):
        return self

    def __next__(self):
        column_name = self._excel_column_name(self.column_number)
        self.column_number += 1
        return str(column_name)

    @staticmethod
    def _excel_column_name(column_number):
        column_name = ""
        while column_number > 0:
            column_number, remainder = divmod(column_number - 1, 26)
            column_name = chr(65 + remainder) + column_name
        return column_name



def createPortGroup(si, dv_switch, pgName):
    dvPGSpec = vim.dvs.DistributedVirtualPortgroup.ConfigSpec()
    dvPGSpec.name = pgName
    dvPGSpec.numPorts = 32
    dvPGSpec.type = vim.dvs.DistributedVirtualPortgroup.PortgroupType.ephemeral

    dvPGSpec.defaultPortConfig = vim.dvs.VmwareDistributedVirtualSwitch.VmwarePortConfigPolicy()

    vlan = vim.dvs.VmwareDistributedVirtualSwitch.VlanIdSpec()
##    vlan.vlanId = extract_numbers_from_end(pgName)
    t = (pgName).split("-")[1]
    vlan.vlanId = extract_numbers_from_end(t)
    dvPGSpec.defaultPortConfig.vlan = vlan

    dvPGSpec.defaultPortConfig.securityPolicy = vim.dvs.VmwareDistributedVirtualSwitch.SecurityPolicy()
    dvPGSpec.defaultPortConfig.securityPolicy.allowPromiscuous = vim.BoolPolicy(value=False)
    dvPGSpec.defaultPortConfig.securityPolicy.forgedTransmits = vim.BoolPolicy(value=False)
    dvPGSpec.defaultPortConfig.securityPolicy.macChanges = vim.BoolPolicy(value=False)
    dvPGSpec.defaultPortConfig.securityPolicy.inherited = False

    # Create uplink teaming policy
    teaming_policy = vim.dvs.VmwareDistributedVirtualSwitch.UplinkPortTeamingPolicy()
    uplinkPortOrder = vim.dvs.VmwareDistributedVirtualSwitch.UplinkPortOrderPolicy()
    if "VMOTION-A" in pgName:
        uplinkPortOrder.activeUplinkPort = ['Uplink 1',]
        uplinkPortOrder.standbyUplinkPort  = ['Uplink 2',]

    elif "VMOTION-B" in pgName:
        uplinkPortOrder.activeUplinkPort = ['Uplink 2',]
        uplinkPortOrder.standbyUplinkPort  = ['Uplink 1',]

    elif "VSAN" in pgName:
        uplinkPortOrder.activeUplinkPort = ['Uplink 2',]
        uplinkPortOrder.standbyUplinkPort  = ['Uplink 1',]

    else: # mgmt & vSAN both are active
        uplinkPortOrder.activeUplinkPort = ['Uplink 1','Uplink 2']

    teaming_policy.uplinkPortOrder = uplinkPortOrder

    dvPGSpec.defaultPortConfig.uplinkTeamingPolicy = teaming_policy
    print("started task: creation of PG %s" % pgName)
    task = dv_switch.CreateDVPortgroup_Task(dvPGSpec)
    results = wait_for_task(task)
    print ("Successfully created DV Port Group ", pgName)
    return dvPGSpec


def extract_numbers_from_end(s):
    numbers = re.findall(r'\d+$', s)
    if len(numbers):
        vlan = int(numbers[0])
        if 0<= vlan <= 4096:
            return int(numbers[0])
        else:
            print('%s: VLAN Format should be like xxxdddd & dddd must be in range 0-4096' % s)
            raise SystemExit()
    else:
        print('%s: VLAN Format should be like xxxdddd' % s)
        raise SystemExit()

def wait_for_task(task, actionName='job', hideResult=False):
    """
    Waits and provides updates on a vSphere task
    """
    from contextlib import suppress

    with suppress(Exception):
        while task.info.state == vim.TaskInfo.State.running:
            time.sleep(2)

        if task.info.state == vim.TaskInfo.State.success:
            if task.info.result is not None and not hideResult:
                out = '%s completed successfully, result: %s' % (actionName, task.info.result)
                print(out)
            else:
                out = '%s completed successfully.' % actionName
                print(out)
        else:
            out = '%s did not complete successfully: %s' % (actionName, task.info.error)
            raise task.info.error
            print (out)

        return task.info.result