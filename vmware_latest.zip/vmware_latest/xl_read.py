import openpyxl
##import
class ExcelColumnIterator:
    """
    class use to get excel column name from A-ZZZ
    """
    def __init__(self,num=1):
        # num is use to start of column name 1 means A
        if isinstance(num,int):
            self.column_number = num
        elif isinstance(num,str) and len(num)==1:
            self.column_number = ord(num.upper()) - 64 # get Char A or depending on num
        else:
            raise SystemExit("num must be integer or single character[a-z]")


    def __iter__(self):
        return self

    def __next__(self):
        # to get next column name
        column_name = self._excel_column_name(self.column_number)
        self.column_number += 1
        return str(column_name)

    @staticmethod
    def _excel_column_name(column_number):
        # private method to calculate column name
        column_name = ""
        while column_number > 0:
            column_number, remainder = divmod(column_number - 1, 26)
            column_name = chr(65 + remainder) + column_name
        return column_name

# Example usage:
iterator = ExcelColumnIterator(num='D')

xlFile = r"C:\work\schwab\NSX_UPGRADE_svs0901bdv.xlsx"
wb = openpyxl.load_workbook(xlFile,data_only=True)
ws = wb.active
t = ws["D15"].value # AK
print(ws.max_row,ws.max_column)
pg_name = []
toCreate = {}
for a_ in range(1,ws.max_column-2):
    col = next(iterator)
    vds = ws[col+str(7)].value
    pg_name = []
    for _ in range(43,47):
##        print(col+str(_))
##        t = ws["D15"].value
##        print(vds, ws[col+str(_)].value)
        if ws[col+str(_)].value != None:
            pg_name.append(ws[col+str(_)].value)
    pg_name = list(set(pg_name))
    toCreate.setdefault(vds,pg_name)
for dvs,pgs in toCreate.items():
    for item in pgs:
        print(dvs, item)

print(toCreate)


