#-------------------------------------------------------------------------------
# Name:        module1
#-------------------------------------------------------------------------------
import json
def generate_temp_filename(suffix='', prefix='tmp'):
    from datetime import datetime
    timestamp = datetime.now().strftime('%Y_%m_%d_%H%M%S')
    filename = f"{prefix}_{timestamp}{suffix}"
    return filename

# Example usage:
temp_filename = generate_temp_filename(suffix='.json')
print(temp_filename)


def toUnderscore(s):
    import re
    pat = r"""(?!-)\W|\s"""
    s = re.sub(pat,'_',s)
    return s

def isUUID(string):
    import uuid
    try:
        uuid.UUID(string)
        return True
    except ValueError:
        return False

sfile = "5739559-AWDEEXT1_Groups_nsx-35-156-132-247_cgw.json"
sfile = "5739559-AWAUEXT1_Groups_nsx-3-106-87-192_mgw.json"
def replaceWrite(sfile,old_word, new_word, dfile='output.json'):
    import json

    # Load the JSON file
    with open(sfile) as f:
        data = json.load(f)

    # Define the words to replace
    old_word = old_word
    new_word = new_word

    # Recursively replace the words in the JSON data
    def replace_words(data):
        if isinstance(data, dict):
            return {key.replace(old_word, new_word): replace_words(value) for key, value in data.items()}
        elif isinstance(data, list):
            return [replace_words(item) for item in data]
        elif isinstance(data, str):
            return data.replace(old_word, new_word)
        else:
            return data

    # Replace the words
    data = replace_words(data)

    # Save the modified JSON data to a new file
    with open(dfile, 'w') as f:
        json.dump(data, f, indent=2)

##replaceWrite("output.json","xxxx", "QQQQ", dfile='output_QQQQ.json')

with open(sfile) as f:
    data = json.load(f)

uidDB = {}
for item in data['results']:
    print(item['display_name'], item['id'])
    if isUUID(item['id']):
        newID = toUnderscore(item['display_name'])
    else:
        newID = item['id']
    uidDB.setdefault(item['id'],[item['display_name'],newID] )

temp_filename = generate_temp_filename(prefix='uidDB', suffix='.json')
with open(temp_filename, 'w') as f:
    json.dump(uidDB, f, indent=2)

##print(uidDB)

def main():
    pass

if __name__ == '__main__':
    main()
