#-------------------------------------------------------------------------------
# Name:        module2
#-------------------------------------------------------------------------------
from openpyxl import load_workbook


##import
class ExcelColumnIterator:
    def __init__(self,num=1):
        if isinstance(num,int):
            self.column_number = num
        elif isinstance(num,str) and len(num)==1:
            self.column_number = ord(num.upper()) - 64
        else:
            raise SystemExit("num must be integer or single character[a-z]")


    def __iter__(self):
        return self

    def __next__(self):
        column_name = self._excel_column_name(self.column_number)
        self.column_number += 1
        return str(column_name)

    @staticmethod
    def _excel_column_name(column_number):
        column_name = ""
        while column_number > 0:
            column_number, remainder = divmod(column_number - 1, 26)
            column_name = chr(65 + remainder) + column_name
        return column_name



def readColumns(file, sheet ='Values', col='D', row=16):
    ''' Return a list of all values at a given row and all columns in file'''
##    file = r'C:\work\schwab\NSX_UPGRADE_svs0901pdv.xlsx'
    iterator  = ExcelColumnIterator(num=col)
    wb = load_workbook(file, data_only=True)
    ws = wb[sheet]
    max_col = ws.max_column
    list_uplink_profile = []
    for a_ in range(1,ws.max_column-2):
        col = next(iterator)
        list_uplink_profile.append(ws[col+str(row)].value)

    list_uplink_profile = list(set(list_uplink_profile))
    list_uplink_profile.remove(None)
    return list_uplink_profile

##file = r'C:\work\schwab\NSX_UPGRADE_svs0901pdv.xlsx'
##readColumns(file, sheet ='Values', col='D', row=16)
##
##def main():
##    pass
##
##if __name__ == '__main__':
##    main()
