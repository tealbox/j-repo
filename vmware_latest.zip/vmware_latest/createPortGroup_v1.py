#-------------------------------------------------------------------------------
# Name:        To create Port groups on a given DVS
# Version:     1.0, creation
# Version:     1.1, documentation
#-------------------------------------------------------------------------------

import atexit
import sys, re
import time, openpyxl

from pyVmomi import vim, vmodl # pyVmomi VMware SDK implementation
from pyvim import connect # VMware SDK implementation for connection to VC
from pyvim.connect import Disconnect
from ExcelColumnIterator import * # custom class for excel column generator for getting column name like 'A', 'B', 'C'
import argparse, getpass # parsing command line, and getpass for password input
import ssl # ssl implementation

context = ssl.create_default_context()
context.check_hostname = False
context.verify_mode = ssl.CERT_NONE

def get_obj(content, vimtype, name):
    """
    Get the vsphere object associated with a given text name,
    eg to get VDS object, give VDS name it will return obj
    """
    obj = None
    container = content.viewManager.CreateContainerView(content.rootFolder, vimtype, True)
    for c in container.view:
        if c.name == name:
            obj = c
            break
    # return None if nothing found
    return obj

class CustomException(BaseException):
    """Custom exception class if obj not found"""
    pass

def wait_for_task(task, actionName='job', hideResult=False):
    """
    Waits and provides updates on a vSphere task
    """
    from contextlib import suppress

    with suppress(Exception):
        while task.info.state == vim.TaskInfo.State.running:
            time.sleep(2)

        if task.info.state == vim.TaskInfo.State.success:
            if task.info.result is not None and not hideResult:
                out = '%s completed successfully, result: %s' % (actionName, task.info.result)
                print(out)
            else:
                out = '%s completed successfully.' % actionName
                print(out)
        else:
            out = '%s did not complete successfully: %s' % (actionName, task.info.error)
            raise task.info.error
            print (out)

        return task.info.result

class Password(argparse.Action):
    """
    class to handle password during argument parsing, it will not echo password
    """
    def __call__(self, parser, namespace, values, option_string):
        if values is None:
            values = getpass.getpass() # to get password without echo
        setattr(namespace, self.dest, values) # set attribute for value

def main():
    # declare all input variables required to create PG e.g
    # VC, username, password, input XLS file.

    parser = argparse.ArgumentParser(description=":: PortGroup Create ::")
    parser.add_argument('-x', '--xls', dest="xls", type=str, default=None, required=True, help='input xls file')
    parser.add_argument('-vc', '--vcenter', dest="vcenter", type=str, default=None, required=True, help='vCenter IP/FQDN')
    parser.add_argument('-u', '--username', dest="username", type=str, default=None, required=True,help='vCenter username')
    parser.add_argument('-p', action=Password, nargs='?', dest='password', help='vCenter Password')
    args = parser.parse_args()
    xlsFile = args.xls

   # xlsFile = "vc_inputs_schwab.xlsx"
   # open file for reading XLS
    wb = openpyxl.load_workbook(xlsFile,data_only=True)
    ws = wb.active
    iterator = ExcelColumnIterator(num='D') # choose 'D' column
    try:
        si = None
        try:
            print ("Trying to connect to VCENTER SERVER . . .")
            # connect to vCenter else throw error
            si = connect.Connect(args.vcenter, 443, args.username, args.password, sslContext=context)
        except IOError:
            pass
            atexit.register(Disconnect, si)

        print ("Connected to VCENTER SERVER !")

        content = si.RetrieveContent() # get VC object connect
##        datacenter = get_obj(content, [vim.Datacenter], inputs['datacenter'])
##        cluster = get_obj(content, [vim.ClusterComputeResource], inputs['cluster'])
##        network_folder = datacenter.networkFolder


        pg_name = []
        toCreate = {}
        # toCreate is a dict for getting all inputs from XLS
        for a_ in range(1,ws.max_column-2):
            col = next(iterator)
            vds = ws[col+str(7)].value
            pg_name = []
            for _ in range(43,47):
                if ws[col+str(_)].value != None:
                    pg_name.append(ws[col+str(_)].value)
            pg_name = list(set(pg_name))
            toCreate.setdefault(vds,pg_name)

        # iterate over a list of all inputs to create objects
        for dvs_name,pgs in toCreate.items():
            # to get dv swtich name
            dv_switch = get_obj(content, [vim.dvs.VmwareDistributedVirtualSwitch], dvs_name)
            print("\nPortGroup creation for DVS: %s" % dvs_name)
            for item in pgs:
                dvPGSpec = createPortGroup(si, dv_switch, item)
                print( dv_switch, item)
                time.sleep(5)
                content = si.RetrieveContent() # retrive again contents to see if object is already

    except vmodl.MethodFault:
        print ("Caught vmodl fault: %s" % vmodl.MethodFault)
        pass
##        return 1
    except CustomException as e :
        print ("Caught exception: %s" % e)
        pass
##        return 1

# Start program
if __name__ == "__main__":
    main()