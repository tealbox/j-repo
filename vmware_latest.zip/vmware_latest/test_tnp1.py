from openpyxl import load_workbook

def readColumns(file, sheet ='Values'):
    ''' Return a list of all values at a given row and all columns in file'''
    file = r"C:\work\trintech\inputs\NSX_UPGRADE_LABNUC.xlsx"
    wb = load_workbook(file, data_only=True)
    ws = wb[sheet]
    max_col = ws.max_column

    vds = ws["D7"].value
    uplink = ws["D16"].value
    tnp = ws["D18"].value
    pool = ws["D53"].value
    tz = ws["D54"].value

    print(vds, uplink, tnp, pool, tz.split(","))
    return (vds, uplink, tnp, pool, tz.split(","))


readColumns('aa')