#-------------------------------------------------------------------------------
# Name:        To validate input_xls_file
# Version:     1.0, creation
# Version:     1.1, documentation
#-------------------------------------------------------------------------------

### XLS file must be .xlsx
### file must be five sheets named as, ['README', 'Data', 'Values', 'Automated', 'PrecheckTracking', 'CRQs', 'DB']
### First letter of each sheet normally CAPS

## import session
from openpyxl import load_workbook

class SheetNotFound(Exception):
    pass

def validateXLS(file):
    ''' Return a True/False if file is valid'''

    default_sheets = ['README', 'Data', 'Values', 'Automated', 'PrecheckTracking', 'CRQs', 'DB']
    wb = load_workbook(file, data_only=True)
    allSheets = True # assuming all sheets exist if not raise error
    for sheet in wb.sheetnames:
        if not sheet in default_sheets:
            print("[{}] sheet does not exist in the XLS File [{}]".format(sheet, file))
            allSheets = False
    return allSheets


file = r"C:\work\vmware_latest_documentation\vmware_latest\inputs\NSX_UPGRADE_svs0901bdv.xlsx"

print(validateXLS(file))

def main():
    pass

if __name__ == '__main__':
    main()
