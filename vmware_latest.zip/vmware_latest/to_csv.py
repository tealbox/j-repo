#-------------------------------------------------------------------------------
# Name:        to create CSV files
# Version:     1.0, creation
# Version:     1.1, documentation
#-------------------------------------------------------------------------------

from myXLS import fast_openpyxl # XLS custom module for processing XLS files.
import os,argparse # os module for Operating system tasks, argparse is for parsing command line arguments
import jinja2 # for creating templates
import csv # for CSV operations

def clear_screen():
    # clear OS screen, only Windows implementation
    # extend for Linux/UNIX
    os.system('cls' if os.name == 'nt' else 'clear')
    print("\n\n")



def main():

    clear_screen()
    parser = argparse.ArgumentParser(description=":: to create csv files ::")
    # input argument XLS file to process
    parser.add_argument('-x', '--xls', dest="xls", type=str, default=None, required=True, help='input xls file to process')

    args = parser.parse_args()
    xlFile = args.xls

    # method to read XLS file and convert to json
    (_, wb) = fast_openpyxl(xlFile)

    output_path = rf'output\{xlFile.split(".")[0].split("_")[-1]}'
    # NSX_UPGRADE_svs0901bdv.xlsx extract svs0901bdv

    try:
        if os.path.isdir(output_path) and os.access(output_path, os.W_OK):
            print(f"Directory {output_path} exists and Writable")
        else:
            print("Directory output not found, creating it")
            os.mkdir(rf'{output_path}')

    except FileNotFoundError:
        print(f"Directory [{output_path}] output not found, creating it")

    # template for creating CSV pair
    ##{{ "Hello" if item is none else item }}
    # Define the template
    template = jinja2.Template("""
    {%- for key, value in data.items() %}
    {{ key | trim }},{{ value if value != "None"  else "" }}
    {%- endfor %}
    """)

    ##print(wb['sheet_Values'])
    for row in wb['sheet_Automated']: # from Automated sheet
        if row['source_vc'] != '0': # if source_vc is not empty else do nothing :)
    ##        print(row)
            csv_data = template.render(data=row)
    ##        print(csv_data)
                # Write the CSV data to a file
            cFile = f'{output_path}\phase3_{row["SourceCluster"]}.csv'
            if csv_data[0] == '\n':
                csv_data = csv_data.lstrip(csv_data[0])
            print(f"creating file: {cFile}...")
            with open(cFile, "w") as f:
                f.write(csv_data)


if __name__ == '__main__':
    main()
