#-------------------------------------------------------------------------------
# Author:      ashok.chauhan
# File:        createSecurityPolicy.py
#-------------------------------------------------------------------------------
from sdwan import *
from sdwan_utils.utils import *
from sdwan_utils.payloads import *
import csv
from SecurityPolicyV3 import *
CONTEXT_SETTINGS = dict(token_normalize_func=lambda x: x.lower())
@click.command(context_settings=CONTEXT_SETTINGS)
@click.option("--vmanage",  '-v', prompt="vManage IP", default='10.10.20.90', required=True)
@click.option("--username", '-u', prompt="vManage Username", default='admin', required=True)
@click.option("--password", '-p', prompt="Password", hide_input=True, required=True, default='C1sco12345')
@click.option("--securitypolicyfile", '-f', prompt="Security Policy csv File", default='gs/securityPolicyfile.xlsx', required=True)
def cli(vmanage, username, password, securitypolicyfile):
    # check file exist or not
    try:
        os.lstat(securitypolicyfile)
    except FileNotFoundError as e:
        print("File not found!! %s" % securitypolicyfile)
        raise SystemExit()
##
    c90 = mySDWAN(vManage=vmanage,username=username, passcode=password)
    payload = createSecurityPolicy(c90, securityGS=securitypolicyfile)
    c90.post(api='/template/policy/security', payload=payload)


if __name__ == "__main__":
    cli()