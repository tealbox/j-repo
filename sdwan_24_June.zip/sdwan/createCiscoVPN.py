#-------------------------------------------------------------------------------
# Author:      ashok.chauhan
# File:        createCiscoVPN.py
#-------------------------------------------------------------------------------
from sdwan import *
from sdwan_utils.utils import *
from sdwan_utils.payloads import *
import csv

CONTEXT_SETTINGS = dict(token_normalize_func=lambda x: x.lower())
@click.command(context_settings=CONTEXT_SETTINGS)
@click.option("--vmanage",  '-v', prompt="vManage IP", default='10.10.20.90', required=True)
@click.option("--username", '-u', prompt="vManage Username", default='admin', required=True)
@click.option("--password", '-p', prompt="Password", hide_input=True, required=True, default='C1sco12345')
@click.option("--servicevpnfile", '-s', prompt="Service VPN csv File", default='gs/serviceCiscoVPN.csv', required=True)
def cli(vmanage, username, password, servicevpnfile):
    # check file exist or not
    try:
        os.lstat(servicevpnfile)
    except FileNotFoundError as e:
        print("File not found!! %s" % servicevpnfile)
        raise SystemExit()
##
    c90 = mySDWAN(vManage=vmanage,username=username, passcode=password)
##    srch = hcSearch(vManage=vmanage,headers=c90.headers)

    allRecords = []

    with open(servicevpnfile, "r", encoding='utf-8-sig') as f:
        for item in csv.DictReader(f):
            allRecords.append(item)

##    print(allRecords)
    for item in allRecords:
        api = '/template/feature'
        payload = createVPNPayload(item["templateName"], item['vpn'], templateDescription=item["templateDescription"])
        res = c90.post(api=api,payload=payload)
##        print(type(res), res)
        if 'templateId' in res:
            print("created Feature Template: %s, templateId: %s" % (item["templateName"], res['templateId']))


if __name__ == "__main__":
    cli()