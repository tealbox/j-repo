import click
from sdwan_utils.cliOptions import *
from sdwan_utils.myCSV import *
from sdwan import *
import time
# templateId, deviceCSV
@click.command(context_settings=CONTEXT_SETTINGS)
@cliOptions
@click.option("--templateId", '-t', prompt="Template ID", required=True, help='Template ID to be applied')
@click.option("--deviceCSV",  '-d', prompt="Template CSV File", default='gs/portfile.csv', required=True, help='CSV file, Default: gs/templateCSV.csv')
def cli(**cliArgs):
##    print(cliArgs["vmanage"],cliArgs["username"],cliArgs["password"],cliArgs["portfile"])
    c90 = mySDWAN(vManage=cliArgs["vmanage"],username=cliArgs["username"], passcode=cliArgs["password"])
    templateCSV = readCSV(inFile=cliArgs["devicecsv"])
    if templateCSV is None:
        print("Issue in payload creation check CSV file: %s" % cliArgs["devicecsv"])
    else:
        payload = c90.attachDTPayload(cliArgs["templateid"], templateCSV)
        res = c90.attachDTemplate(payload=payload)
        print(res)
        if 'id' in res:
            statusId = res.get('id',None)

            if statusId:
                taskStatus = "InProgress"
                api = f"/device/action/status/{statusId}"
                statusRes = c90.get(api=api)
##                    statusRes = statusRes.get('validation', None)
                print("\n\nAttaching template to Device")
                print(*statusRes['validation']['activity'], sep = "\n")
                while taskStatus != "done":
                    statusRes = c90.get(api=api)
##                    statusRes = statusRes.get('validation', None)
                    print(statusRes['summary']['status'], statusRes['summary']['count'])
                    taskStatus = statusRes['summary']['status']
                    if 'Failure' in statusRes['summary']['count']:
                        print("\n\n", "-"*60, sep="")
                        print("Not able to attach template, review CSV file")
                        print(payload)
                    if 'Success' in statusRes['summary']['count']:
                        print("\n\n", "-"*60)
                        print("Successfully attached template to Device")
                    time.sleep(3)
        else:
            print("Not able to attached file, correct CSV/Try Again")

if __name__ == "__main__":
    cli()