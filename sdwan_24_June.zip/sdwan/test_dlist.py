#-------------------------------------------------------------------------------
# Name:        module3
#------------------------------------------------------------------------------
##from sdwan_utils.utils import *

def split_n_removeSpace(inStr=None,sep1=",", sep2="-"):
    tempStr = []
    if inStr is None:
        return None
    if sep1 in inStr:
        tempStr = [item.strip() for item in inStr.split(sep=sep1) if len(item) > 1]
##        print(tempStr)
    elif sep2 in inStr:
        count = inStr.count(sep2)
        if count > 1:
            print("Issue with %s must in the format 7-9, only one Hyphen(-)" % inStr)
        else:
            # split and remove space
            p1,p2 = inStr.split(sep=sep2)
            return f'{p1}-{p2}'
    if not (sep1 in inStr) and not (sep2 in inStr):
        if len(inStr) < 1:
            return None
        else:
            return inStr
    # check each item if second sep exist - hyphon
    for idx, item in enumerate(tempStr):
        if sep2 in item:
            count = item.count(sep2)
##            print(item , count)
            if count > 1:
                print("Issue with %s must in the format 7-9, only one Hyphen(-)" % item)
            else:
                # split and remove space
                p1,p2 = [item.strip() for item in item.split(sep=sep2)]
                tempStr[idx] = f'{p1}-{p2}'
    print(tempStr)
    return tempStr




def portEntries(portStr=None):
    # number must be in Range: 0-65530
    portStr = str(portStr)
    if portStr is None or len(portStr) < 1:
        return None
##    if not checkPort(portStr):
##        return None
    else: # create list of ipPrefix
        portStr = portStr.strip()
        if portStr[-1] == ",":
            portStr = portStr[:-1]

        entriesList = []
        portList = split_n_removeSpace(inStr=portStr)
##        print("l: ", portList)
        if isinstance(portList, (list,)):
            for item in portList:
                # convert to number
                if str.isnumeric(item):
                    port = int(item)
                    if not 0 <= port <= 65530:
                        print("Port %s is out of range 0-65530" % port)
                        raise SystemExit()
                elif "-" in item:
                    p1,p2 = item.split("-")
                    if str.isnumeric(p1) and str.isnumeric(p2):
                        p1 = int(p1)
                        p2 = int(p2)
                        if not 0 <= p1 <= 65530 and  0 <= p2 <= 65530:
                            print("Port %s is out of range 0-65530" % item)
                            raise SystemExit()
                    else:
                        print("Port %s is not in right format" % item)
                        raise SystemExit()
                else:
                    print("Port %s is not in right format" % item)
                    raise SystemExit()
                entriesList.append( {"port": item} )
        else:
            entriesList.append( {"port": portList} )
        return entriesList

def portPayload(name, desc=None, objType="port", portStr=None):
    if portStr is None:
        return None
    entries = portEntries(portStr=portStr) # validate all numbers and in the range 0 - 65535
    if entries is None:
        return None
    else:
        return { \
            "name":name,\
            "description":desc,\
            "type":"port",\
            "entries": entries
            }


payload = portPayload("MyList", desc="API DESC", objType="port", portStr=21)
print(payload)
payload = portPayload("MyList", desc="API DESC", objType="port", portStr="22-23")
print(payload)
split_n_removeSpace("21")
split_n_removeSpace("50.50.50.0    -     10/24,       30.30.30.0/24,,,,,,")
def main():
    pass

if __name__ == '__main__':
    main()
