#-------------------------------------------------------------------------------
# Author:      ashok.chauhan
#-------------------------------------------------------------------------------
from sdwan_utils.cliOptions import *
from sdwan import *
@click.command(context_settings=CONTEXT_SETTINGS)
@cliOptions
@click.option("--objtype", '-o', prompt="Object Type", default='', required=True,help='object: dataprefix,zone,port,class,zonebasedfw')
def cli(vmanage, username, password, objtype):
    c90 = mySDWAN(vManage="10.10.20.90", username = "admin", passcode="C1sco12345", gs="")
##    apiList = ["/template/policy/list/dataprefix" , "/template/policy/list/port", "/template/policy/list/zone", '/template/policy/list/class']
    appDict = {}
    appDict.setdefault('dataprefix', "/template/policy/list/dataprefix")
    appDict.setdefault('port', "/template/policy/list/port")
    appDict.setdefault('zone', "/template/policy/list/zone")
    appDict.setdefault('class', "/template/policy/list/class")
    appDict.setdefault('zonebasedfw', "/template/policy/definition/zonebasedfw")

    if objtype in appDict:
        api = appDict[objtype]
        objects = c90.get(api=api, method="GET", payload={})
        print([item['listId'] for item in objects['data']])
        if objects.get('data', None):
            # check if empty
            data = objects.get('data', None)
            if len(data):
                # get a list of all items in the data
                for delItem in data:
                    print("Deleting object %s" % delItem['listId'])
                    url = f'{c90.baseUrl}{api}/{delItem["listId"]}'
                    c90.s.delete(url, headers = c90.headers)
    else:
        print("No such object type: %s" % objtype)

##    for objtype in appDict:
##        apiItem = appDict[objtype]
##        objects = c90.get(api=apiItem, method="GET", payload={})
##        # print(objects)
##        if objects.get('data', None):
##            # check if empty
##            data = objects.get('data', None)
##            if len(data):
##                # get a list of all items in the data
##                for delItem in data:
##                    print("Deleting object %s" % delItem['listId'])
##                    url = f'{c90.baseUrl}{apiItem}/{delItem["listId"]}'
##                    c90.s.delete(url, headers = c90.headers)

    pass

if __name__ == '__main__':
    cli()
