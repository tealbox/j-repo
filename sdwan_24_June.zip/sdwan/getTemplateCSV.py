import click
from sdwan import *
from hc_SearchClass import *
from tabulate import tabulate
@click.command()
@click.option("--vmanage",  '-v', prompt="vManage IP", default='10.10.20.90', required=True)
@click.option("--username", '-u', prompt="vManage Username", default='admin', required=True)
@click.option("--password", '-p', prompt="Password", hide_input=True, required=True, default='C1sco12345')
@click.option("--template", '-t', prompt="Template Name/ID", default='711e5457-99a9-4eac-aade-a7f7c431ee95', required=True)
def cli(vmanage, username, password, template):
    c90 = mySDWAN(vManage=vmanage,username=username, passcode=password)
    hcs = hcSearch(vManage=vmanage,headers=c90.headers)
    allDT = hcs.getTemplates()
    _template = template.lower()
    if _template in allDT:
        templateId =  allDT[_template]['templateId']
    else:
        click.echo("%s not found, Please check Template name & run again" % template)
        raise SystemExit()
    rawData = c90.getTemplateCSV()

    rawData = rawData.get('header').get('columns')
    if rawData != None:
        with open(f"{template}_ToBeFilled.csv","w") as f:
            for item in rawData:
                f.write(item['property'])
                f.write(',')
##                print(item['property'])

if __name__ == "__main__":
    cli()