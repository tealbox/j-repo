#-------------------------------------------------------------------------------
# Name:        module3
#-------------------------------------------------------------------------------
import csv
import os, string
def readCSV(inFile=None):
    try:
        os.lstat(inFile)
    except FileNotFoundError as e:
        print("File not found!! %s" % servicevpnfile)
        raise SystemExit()
    try:
        allRecords = []
        with open(inFile, newline='') as csvfile:
            start = csvfile.read(4096)
            # isprintable does not allow newlines, printable does not allow umlauts...
            if not all([c in string.printable or c.isprintable() for c in start]):
                print("Non-Printable characters")
                raise SystemExit()
##            dialect = csv.Sniffer().sniff(start)
##            print(dialect.delimiter)
            csvfile.seek(0)
            csv_reader = csv.DictReader(csvfile,quotechar="'" , skipinitialspace=True, quoting=csv.QUOTE_STRINGS)
            data = [row for row in csv_reader]
            return data

##            for line in csv.reader(csvfile, delimiter=',', quoting=csv.QUOTE_STRINGS):
##                allRecords.append(line)
##                print(line)
##            return allRecords

    except csv.Error as e:
        print("Error in CSV file %s" % inFile)
        print(e)
        raise SystemExit()


def main():
    allRecords = readCSV(inFile="gs/dataprefixIPv4.csv")
    print(allRecords)

if __name__ == '__main__':
    main()
