#-------------------------------------------------------------------------------
# Author:       ashok.chauhan
# Version:      v1.5
#-------------------------------------------------------------------------------
## use module as below
### from sdwan_utils.utils import *
from ipaddress import ip_address
import re, os
from datetime import datetime
import json
from uuid import UUID
from pathlib import Path


def isValidIP(ipStr=None):
    if ipStr is None:
        return False
    if "/" in ipStr:
        # ip address also have netmask check number must be in range 1..32
        # slip and trim
        (ip,mask) = ipStr.split("/")
        try:
            ip = ip.strip() # remove white spaces from ip and mask
            mask = int(mask.strip())
##            print(mask)
            if 8 <= mask <= 32:
##                print(ip)
                ip_address(ip)
                return True
            else:
                return False
        except ValueError:
            return False
    try:
        ip_address(ipStr)
        return True
    except ValueError:
        return False

def checkIPStr(ipStr=None):
    if ipStr is None:
        return False
    if "," in ipStr:
        l = ipStr.split(",")
        for item in l:
            if not isValidIP(item):
                return False
        return True
    elif not isValidIP(ipStr): # could be a single IP
        return False
    else:
        return True

def ipPrefix(ipStr=None):
    if ipStr is None:
        return None
    if not checkIPStr(ipStr):
        return None
    else: # create list of ipPrefix
        prefixList = []
        l = ipStr.split(",")
        for item in l:
            prefixList.append( {"ipPrefix": item} )
        return prefixList

def dataPrefixPayload(name, desc=None, objType="dataprefix", ipStr=None):
    if ipStr is None:
        return None
    prefixList = ipPrefix(ipStr=ipStr)
    if prefixList is None:
        return None
    else:
        return { \
            "name":name,\
            "description":desc,\
            "type":"dataprefix",\
            "entries": prefixList
            }

def createListPayload(name, dtype, entries):
    return json.dumps({ \
        "name": name,\
        "type":dtype, \
        "entries":entries \
        })

def removeSpecialChar(s):
    pat = r"""\s|[\[\]\(\)\{\}})]"""
    s = re.sub(pat,'',s)
    return s

def classItemParse(item,dtype):
#     print(item['name'],item['entries_type'],item['entries_data'],)
    entriesList = []
    if item['entries'] != None and item['entries'] != "":
        entries_data = str(item.get('entries'))
        entries_data = removeSpecialChar(entries_data)
        if "," in entries_data:
            # split
            l =  [xItem.strip() for xItem in entries_data.split(',')]
            # [{"interface":"Loopback1"}]
            [entriesList.append({f"{dtype}":sitem}) for sitem in l]
        else:
            entriesList.append({f"{dtype}":entries_data})
    return entriesList


def transform(data, key):
    # data must be a list of dict
    if (not isinstance(data,(list,))) and len(data) == 0 and key not in data[0]:
        print("Data must be list of dict and atlead one item")
        return None
    temp = {}
    for item in data:
        temp.setdefault(item[key], item)
    return temp

def testUUID(tstUUID):
    from uuid import UUID
    try:
        _ = UUID(tstUUID)
    except ValueError:
        return False
    return True

def getID(data, key):
    # data must be dict
    if not isinstance(data, (dict,)):
        print("Data is not in json format")
        return None
    if key in data:
        # get a list of all
        keys = []
        [keys.append(k) for k in data[key].keys() if 'id' in k or 'Id' in k]
        # check which id having uuid value.
        for tkey in keys:
            if testUUID(data[key][tkey]):
                return data[key][tkey]

def getCSVPayload(templateId):
    return json.dumps({"templateId":templateId,"isEdited":False,"isMasterEdited":False} )




def removeSpecialChar(s):
    pat = r"""\s|[\[\]\(\)\{\}})]"""
    s = re.sub(pat,'',s)
    return s

def zoneItemParse(item):
#     print(item['name'],item['entries_type'],item['entries_data'],)
    interfaceList = []
    if item['entries_type'] != None and item['entries_type'] != "" and item['entries_data'] != None and item['entries_data'] != "":
        # check if entries_data is
        if item.get('entries_type', None).lower() == 'interface':
            # check if contain comma in entries_data then spilt
            if "," in item.get('entries_data', None):
                # split
                l = item.get('entries_data', None).split(",")
                # [{"interface":"Loopback1"}]
                for sitem in l:
                    interfaceList.append({"interface":sitem})
            else:
                interfaceList.append({"interface":item.get('entries_data', None)})
        elif item.get('entries_type', None).lower() == 'vpn':
            # converted to str for special case as Single entry will be integer
            entries_data = str(item.get('entries_data'))
            if "," in entries_data:
                # split
                l = entries_data.split(",")
                # [{"interface":"Loopback1"}]
                for sitem in l:
                    interfaceList.append({"vpn":sitem})
            else:
                interfaceList.append({"vpn":entries_data})
        else:
            print(f"item['entries_type']= Should not be interface or vpn")
    else:
        print(f"item['entries_type']= Should not be Blank")

    return interfaceList

def portItemParse(item,dtype):
#     print(item['name'],item['entries_type'],item['entries_data'],)
    entriesList = []
    if item['entries'] != None and item['entries'] != "":
        entries_data = str(item.get('entries'))
        entries_data = removeSpecialChar(entries_data)
        if "," in entries_data:
            # split
            l =  [xItem.strip() for xItem in entries_data.split(',')]
            # [{"interface":"Loopback1"}]
            [entriesList.append({f"{dtype}":sitem}) for sitem in l]
        else:
            entriesList.append({f"{dtype}":entries_data})
    return entriesList

def createListPayload(name, dtype, entries):
    return json.dumps({ \
        "name": name,\
        "type":dtype, \
        "entries":entries \
        })


### Version 1.5
def getvManageIP(configFile=None):
    # os & pathlib modules are required
    if not configFile:
        _ = Path(".")
        configFile = _ / "vManage.ini"
    # read file and ignore # lines
    configFile =  Path(configFile)
    with open(configFile, "r") as f:
        lines = f.readlines()
    for line in lines:
        if "#" in line and "\n" in line:
            continue
        if "vManage" in line:
            if "=" in line:
                l = line.split("=")
                if len(l) < 2:
                    print("Invalid format in vManage.ini file, should be vManage=10.10.20.90")
                    print("Correct and rerun")
                    raise SystemExit()
                else:
                    ip = l[1]
                    # check for valid IP
                    if isValidIP(ip):
                        return ip
            else:
                print("Invalid format in vManage.ini file, should be vManage=10.10.20.90")
                print("Correct and rerun")
                raise SystemExit()



def split_n_removeSpace(inStr=None,sep1=",", sep2="-"):
    tempStr = []
    if inStr is None:
        return None
    if sep1 in inStr:
        tempStr = [item.strip() for item in inStr.split(sep=sep1)]
        print(tempStr)
    elif sep2 in inStr:
        count = inStr.count(sep2)
        if count > 1:
            print("Issue with %s must in the format 7-9, only one Hyphen(-)" % inStr)
        else:
            # split and remove space
            p1,p2 = item.split(sep=sep2)
            return f'{p1}-{p2}'
    else:
        return
    # check each item if second sep exist - hyphon
    for idx, item in enumerate(tempStr):
        if sep2 in item:
            count = item.count(sep2)
            print(item , count)
            if count > 1:
                print("Issue with %s must in the format 7-9, only one Hyphen(-)" % item)
            else:
                # split and remove space
                p1,p2 = [item.strip() for item in item.split(sep=sep2)]
                tempStr[idx] = f'{p1}-{p2}'
    print(tempStr)
    return tempStr







def portEntries(portStr=None):
    # number must be in Range: 0-65530
    if portStr is None:
        return None
##    if not checkPort(portStr):
##        return None
    else: # create list of ipPrefix
        portStr = portStr.strip()
        if portStr[-1] == ",":
            portStr = portStr[:-1]

        entriesList = []
        l = split_n_removeSpace(inStr=portStr)
        for item in l:
            # convert to number
            if str.isnumeric(item):
                port = int(item)
                if not 0 <= port <= 65530:
                    print("Port %s is out of range 0-65530" % port)
                    raise SystemExit()
            elif "-" in item:
                p1,p2 = item.split("-")
                if str.isnumeric(p1) and str.isnumeric(p2):
                    p1 = int(p1)
                    p2 = int(p2)
                    if not 0 <= p1 <= 65530 and  0 <= p2 <= 65530:
                        print("Port %s is out of range 0-65530" % item)
                        raise SystemExit()
                else:
                    print("Port %s is not in right format" % item)
                    raise SystemExit()
            else:
                print("Port %s is not in right format" % item)
                raise SystemExit()
            entriesList.append( {"port": item} )
        return entriesList

def portPayload(name, desc=None, objType="port", portStr=None):
    if portStr is None:
        return None
    entries = portEntries(portStr=portStr) # validate all numbers and in the range 0 - 65535
    if entries is None:
        return None
    else:
        return { \
            "name":name,\
            "description":desc,\
            "type":"port",\
            "entries": entries
            }

##############################Helper###########################################################
def split_n_removeSpace(inStr=None,sep1=",", sep2="-"):
    tempStr = []
    if inStr is None:
        return None
    if sep1 in inStr:
        tempStr = [item.strip() for item in inStr.split(sep=sep1) if len(item) > 1]
##        print(tempStr)
    elif sep2 in inStr:
        count = inStr.count(sep2)
        if count > 1:
            print("Issue with %s must in the format 7-9, only one Hyphen(-)" % inStr)
        else:
            # split and remove space
            p1,p2 = inStr.split(sep=sep2)
            return f'{p1}-{p2}'
    if not (sep1 in inStr) and not (sep2 in inStr):
        if len(inStr) < 1:
            return None
        else:
            return inStr
    # check each item if second sep exist - hyphon
    for idx, item in enumerate(tempStr):
        if sep2 in item:
            count = item.count(sep2)
##            print(item , count)
            if count > 1:
                print("Issue with %s must in the format 7-9, only one Hyphen(-)" % item)
            else:
                # split and remove space
                p1,p2 = [item.strip() for item in item.split(sep=sep2)]
                tempStr[idx] = f'{p1}-{p2}'
##    print(tempStr)
    return tempStr



####################### Port layload ##################################################################
def portEntries(portStr=None):
    # number must be in Range: 0-65530
    portStr = str(portStr)
    if portStr is None or len(portStr) < 1:
        return None
##    if not checkPort(portStr):
##        return None
    else: # create list of ipPrefix
        portStr = portStr.strip()
        if portStr[-1] == ",":
            portStr = portStr[:-1]

        entriesList = []
        portList = split_n_removeSpace(inStr=portStr)
##        print("l: ", portList)
        if isinstance(portList, (list,)):
            for item in portList:
                # convert to number
                if str.isnumeric(item):
                    port = int(item)
                    if not 0 <= port <= 65530:
                        print("Port %s is out of range 0-65530" % port)
                        raise SystemExit()
                elif "-" in item:
                    p1,p2 = item.split("-")
                    if str.isnumeric(p1) and str.isnumeric(p2):
                        p1 = int(p1)
                        p2 = int(p2)
                        if not 0 <= p1 <= 65530 and  0 <= p2 <= 65530:
                            print("Port %s is out of range 0-65530" % item)
                            raise SystemExit()
                    else:
                        print("Port %s is not in right format" % item)
                        raise SystemExit()
                else:
                    print("Port %s is not in right format" % item)
                    raise SystemExit()
                entriesList.append( {"port": item} )
        else:
            entriesList.append( {"port": portList} )
        return entriesList

def portPayload(name, desc=None, objType="port", portStr=None):
    if portStr is None:
        return None
    entries = portEntries(portStr=portStr) # validate all numbers and in the range 0 - 65535
    if entries is None:
        return None
    else:
        return { \
            "name":name,\
            "description":desc,\
            "type":"port",\
            "entries": entries
            }

###############################################################################################
