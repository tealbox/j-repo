import click
from sdwan_utils.cliOptions import *
from sdwan_utils.myCSV import *
from sdwan import *
import time
# templateId, deviceCSV
@click.command(context_settings=CONTEXT_SETTINGS)
@cliOptions
def cli(**cliArgs):
##    print(cliArgs["vmanage"],cliArgs["username"],cliArgs["password"],cliArgs["portfile"])
    c90 = mySDWAN(vManage=cliArgs["vmanage"],username=cliArgs["username"], passcode=cliArgs["password"])
    d = c90.get(api='/template/device')
    w= transform(d['data'],'templateName')
    print(w['templateId', "\t", w['templateName'] ])

if __name__ == "__main__":
    cli()