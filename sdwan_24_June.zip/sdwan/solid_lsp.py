#-------------------------------------------------------------------------------
# Author:      ashok.chauhan
#-------------------------------------------------------------------------------
class Vehicle:
    def move(self):
        pass

class Car(Vehicle):
    def move(self):
        print("Car moving on wheels")

class Boat(Vehicle):
    def move(self):
        print("Boat moving on Water")


myCar = Car()
myCar.move()
myBoat = Boat()
myBoat.move()


# LSP test
def vehicle_move(vehicle: Vehicle):
    vehicle.move()

vehicle_move(myCar)
vehicle_move(myBoat)


def sum(a: int, b: int):
    return a+b

print(sum(10,30))
print(sum('10','30'))


def main():
    pass

if __name__ == '__main__':
    main()
