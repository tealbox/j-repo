#-------------------------------------------------------------------------------
# Name:        Ashok CHAUHAN
# Version:     1.0 Base version to set username, password and encoded
#-------------------------------------------------------------------------------

##  How is use: create object of Authenticate class
##  Authenticate(username='admin', password='VMware1!)
##  if password is less than 5 char it will prompt for the password

from getpass import getpass
class Authenticate:
    def __init__(self, username=None,password=None):
        if username and len(username.strip()) >= 4:  ## root
            self.username = username
        else:
            self.username = self.askUsername()

        if password and len(password.strip()) > 5:
            self.password = password
        else:
            self.password = self.askPassword()

        self.encoded = self.getEncoded()
    #############################################

    @property
    def username(self):
        return self._username
    @username.setter
    def username(self, username):
        self._username = str(username).lower()

    @property
    def password(self):
        return self._password
    @password.setter
    def password(self,password):
        self._password = password


    def askUsername(self):
        return input("Username: ")



    def askPassword(self):
        return getpass(prompt=f'{self.username} Password: ')

    def getCred(self):
        return (self.username, self.password)

    @property
    def encoded(self):
        return self._encoded
    @password.setter
    def encoded(self,encoded):
        self._encoded = encoded


    def getEncoded(self):
        # import encoding
        from base64 import b64encode
        s = f'{self.username}:{self.password}'.encode('utf-8')
        return b64encode(s)


##  How is use: create object of Authenticate class
##  Authenticate(username='admin', password='VMware1!)
##  if password is less than 5 char it will prompt for the password

##def main():
##    c = Authenticate(username='root')
##    print(c.username, c.password)
##    print(c.getEncoded())
##
##    pass
##
##if __name__ == '__main__':
##    main()
