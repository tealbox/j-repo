import click
from sdwan_utils.cliOptions import *

@click.command(context_settings=CONTEXT_SETTINGS)
@cliOptions
@click.option("--securitypolicyfile", '-f', prompt="Security Policy csv File", default='gs/securityPolicyfile.xlsx', required=True, help='XLS file, Default: gs/securityPolicyfile.xlsx')
def cli(**cliArgs):
    print(cliArgs["vmanage"],cliArgs["username"],cliArgs["password"],cliArgs["securitypolicyfile"])


if __name__ == "__main__":
    cli()