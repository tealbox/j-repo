#-------------------------------------------------------------------------------
# Name:        module1
#-------------------------------------------------------------------------------
#-------------------------------------------------------------------------------
# Name:        module1
#-------------------------------------------------------------------------------
from myXLS import *
from pathlib import Path
from pprint import pprint
from collections import OrderedDict
import json
from sdwan import *

def is_template_exist(gt, templateId):
    # gt is a list of dict
##    print("in TEst", templateId)
    for idx, item in enumerate(gt):
        if item.get('templateId', None) == templateId:
            return True, idx
    return False, None

def getFTtemplateId(fTemplates,templateName):
    if templateName in fTemplates:
        return fTemplates[templateName]['templateId']
    else:
        None

def getlpId(lpByName,policyName):
    if policyName in lpByName:
        return lpByName[policyName]['policyId']
    else:
        None


def main():
    c90 = mySDWAN(vManage="44.240.148.173", username = "svc_api_automation", passcode="India@123", gs="")
    fTemplates = c90.featureTemplatesNyName()
    lpByName = c90.localPolicyByName()
    _ = Path(".")
    gs = _ / "gs/Irvine_template v2.xlsx"
    t = OrderedDict("")
    t.setdefault("featureTemplateUidRange",[])
    t.setdefault("factoryDefault",False)
    wb = fast_openpyxl(gs)
    Sample = wb[1]["sheet_Template-Irvine"]
    gt = []
    for line in Sample:
        templateName = line.get("TemplateName", None)
        if templateName == "None":
            templateName = ""
            templateID = ""
##        if str(templateName).lower == "false":
##            templateName = "false"
##        if str(templateName).lower == "true":
##            templateName = "true"
        else:
            # search for template name and get ID
            templateID = getFTtemplateId(fTemplates,templateName)
        if line["Section"] == "template" or line["Section"] == "Security Policy" or line["Section"] == "Policy":
            if line["Section"] == "template":
                t.setdefault(line['Template'], templateName)
            if  line["Section"] == "Security Policy":
                t.setdefault(line['Template'], templateName)
            if line["Section"] == "Policy":
                policyId = getlpId(lpByName,templateName)
                t.setdefault(line['Template'], policyId)

        else:
            # "templateType": "", "templateId": "" optional >> "subTemplates"
            if line['Sub-Template'] != 'None':
##                print("\t", line['Sub-Template'], line['SubTemplateName'])
                status, idx = is_template_exist(gt,templateID)
                if status:
                    if "subTemplates" in gt[idx]:
                        # add item
                        subt = gt[-1]['subTemplates']
                        templateID = getFTtemplateId(fTemplates,line["SubTemplateName"])
                        subt.append({"templateType": line["Sub-Template"], "templateId": templateID})
                        gt[-1].update({'subTemplates':subt})
                        gt[-1].move_to_end("subTemplates", last = True)
                    else:
##                        print("GT[-1]", gt[-1])
                        templateID = getFTtemplateId(fTemplates,line["SubTemplateName"])
                        gt[-1].setdefault("subTemplates", [{"templateType": line["Sub-Template"], "templateId": templateID}])
                        gt[-1].move_to_end("subTemplates", last = True)
##                        print("After GT[-1]", gt[-1])

            else:
                gt.append(OrderedDict({"templateType": line["Template"], "templateId": templateID}))

##    pprint(t)
##    pprint(gt)
    t.setdefault("generalTemplates", gt)
##    pprint(t)
    print(json.dumps(t, indent=2))

if __name__ == '__main__':
    main()
