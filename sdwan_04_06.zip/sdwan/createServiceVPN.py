#-------------------------------------------------------------------------------
# Author:      ashok.chauhan
#-------------------------------------------------------------------------------

from sdwan import *
from pprint import pprint
from pathlib import Path
from myXLS import *
def getServiceVPNIP():
    return \
    {
     'gre-route': {},
     'ipsec-route': {},
     'route': {'vipObjectType': 'tree',
               'vipPrimaryKey': ['prefix'],
               'vipType': 'constant',
               'vipValue': [{'prefix': {'vipObjectType': 'object',
                                        'vipType': 'constant',
                                        'vipValue': '0.0.0.0/0',
                                        'vipVariableName': 'vpn_ipv4_ip_prefix'},
                             'priority-order': ['prefix', 'vpn'],
                             'vpn': {'vipObjectType': 'object',
                                     'vipType': 'constant',
                                     'vipValue': 0}},
                            {'distance': {'vipObjectType': 'object',
                                          'vipType': 'ignore',
                                          'vipValue': 1,
                                          'vipVariableName': 'vpn_ipv4_ip_distance'},
                             'null0': {'vipObjectType': 'node-only',
                                       'vipType': 'constant',
                                       'vipValue': 'true'},
                             'prefix': {'vipObjectType': 'object',
                                        'vipType': 'variableName',
                                        'vipValue': '',
                                        'vipVariableName': 'Branch_LAN_summerise'},
                             'priority-order': ['prefix', 'null0', 'distance']}]},
     'service-route': {}
     }


def createServiceVPNPayload(templateName, vpn_id=None, templateDescription=None, IPv4Route=False):
    if IPv4Route:
        # call
        ipPayload = getServiceVPNIP()
    else:
        ipPayload = {
          "gre-route": {},
          "ipsec-route": {},
          "service-route": {}
        }


    return json.dumps(\
        {
          "templateName": templateName,
          "templateDescription": templateDescription,
          "templateType": "cisco_vpn",
          "deviceType": [
            "vedge-C8000V"
          ],
          "templateMinVersion": "15.0.0",
          "templateDefinition": {
            "vpn-id": {
              "vipObjectType": "object",
              "vipType": "constant",
              "vipValue": vpn_id
            },
            "name": {
              "vipObjectType": "object",
              "vipType": "variableName",
              "vipValue": "",
              "vipVariableName": "vpn_name"
            },

            "tenant-vpn-id": {},
            "org-name": {},
            "omp-admin-distance-ipv4": {
              "vipObjectType": "object",
              "vipType": "ignore",
              "vipVariableName": "vpn_omp-admin-distance-ipv4"
            },

            "ip": ipPayload,
            "ipv6": {},
            "omp": {
              "advertise": {
                "vipType": "ignore",
                "vipValue": [],
                "vipObjectType": "tree",
                "vipPrimaryKey": [
                  "protocol"
                ]
              },
              "ipv6-advertise": {
                "vipType": "ignore",
                "vipValue": [],
                "vipObjectType": "tree",
                "vipPrimaryKey": [
                  "protocol"
                ]
              }
            }
          },
          "factoryDefault": False
        } )


# get a list of current Service VPN and check if already exist or not.






def createVPNInterface(templateName, templateDescription="", interfaceName="", interfaceDescription="", interfaceIPV4Name="" ):
    return \
        {
      "templateName": templateName,
      "templateDescription": templateDescription,
      "templateType": "cisco_vpn_interface",
      "deviceType": [
        "vedge-C8000V"
      ],
      "templateMinVersion": "15.0.0",
      "templateDefinition": {
        "if-name": {
          "vipObjectType": "object",
          "vipType": "constant",
          "vipValue": interfaceName,
          "vipVariableName": "vpn_if_name"
        },
        "description": {
          "vipObjectType": "object",
          "vipType": "constant",
          "vipValue": interfaceDescription,
          "vipVariableName": "vpn_if_description"
        },
        "ip": {
          "address": {
            "vipObjectType": "object",
            "vipType": "variableName",
            "vipValue": "",
            "vipVariableName": interfaceIPV4Name
          },
        },
        "dhcp-helper": {
          "vipObjectType": "list",
          "vipType": "ignore",
          "vipVariableName": "vpn100_if_dhcp_helper"
        },
        "shutdown": {
          "vipObjectType": "object",
          "vipType": "ignore",
          "vipValue": "true",
          "vipVariableName": "vpn_if_shutdown"
        }
      },
      "factoryDefault": False
    }



def createVPNInterfaceDHCP():
    return \
        {
  "templateName": "FT_Global_BR_INTF_GE3.401xxx_v1",
  "templateDescription": "FT_Global_BR_INTF_GE3.401_v1 Desc",
  "factoryDefault": false,
  "templateType": "cisco_vpn_interface",
  "deviceType": [
    "vedge-C8000V"
  ],
  "templateMinVersion": "15.0.0",
  "templateDefinition": {
    "if-name": {
      "vipObjectType": "object",
      "vipType": "constant",
      "vipValue": "GigabitEthernet3.400",
      "vipVariableName": "vpn_if_name"
    },
    "description": {
      "vipObjectType": "object",
      "vipType": "constant",
      "vipValue": "Guest_USER",
      "vipVariableName": "vpn_if_description"
    },
    "ip": {
      "address": {
        "vipObjectType": "object",
        "vipType": "variableName",
        "vipValue": "",
        "vipVariableName": "Vlan_502_ipv4_address"
      }
    },
    "dhcp-helper": {
      "vipObjectType": "list",
      "vipType": "variableName",
      "vipValue": "",
      "vipVariableName": "vlan502_if_dhcp_helper"
    },
    "shutdown": {
      "vipObjectType": "object",
      "vipType": "variableName",
      "vipValue": "",
      "vipVariableName": "Vlan_502_if_shutdown"
    }
  }
}











def main():
    c90 = mySDWAN(vManage="10.10.20.90", username = "admin", passcode="C1sco12345", gs="")
    _ = Path("gs" )
    wkGS = _ / "Irvine_template v2.xlsx"
    wb =    fast_openpyxl(wkGS)
    serviceVPN = wb[1]["sheet_service_cisco_vpn"]
    vpnInterfaces = wb[1]["sheet_cisco_vpn_interface"]

#  ['templateName', 'templateDescription', 'vpn', 'vpnName', 'IPv4Route', 'default', 'null', 'notes']
    for item in serviceVPN:
        IPv4Route = item.get('IPv4Route', None)
        if str(IPv4Route).lower() == 'yes':
            IPv4Route = True
        else:
            IPv4Route = False

        payload = createServiceVPNPayload(item['templateName'], templateDescription=item['templateDescription'], vpn_id=item['vpn'], IPv4Route=IPv4Route)
        res = c90.post(api='/template/feature', payload=payload)


##    for item in vpnInterfaces:
##        print(item)
##        payload = createVPNInterface(item["templateName"], templateDescription=item["templateDescription"], interfaceName=item["interfaceName"], interfaceDescription=item["interfaceDescription"], interfaceIPV4Name=item["interfaceIPV4Name"])
####        print(json.dumps( payload))
##        res = c90.post(api='/template/feature', payload=json.dumps( payload))
##
    pass

if __name__ == '__main__':
    main()
