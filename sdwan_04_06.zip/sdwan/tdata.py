#-------------------------------------------------------------------------------
# Author:      ashok.chauhan
#-------------------------------------------------------------------------------

import csv, json
from pprint import pprint
templateCSV = r"C:\work\sdwan\Site2-cEdge01.csv"

with open(templateCSV, "r") as tcsv:
    temp = csv.DictReader(tcsv)
    tdata = [row for row in temp]

##print( json.dumps(tdata[0]))


def testP(deviceId, deviceIP):
    payload = json.dumps(
        {
          "deviceType":"vedge",
          "devices":[
            {
            "deviceId": f"{deviceId}",
            "deviceIP": f"{deviceIP}"
            }
          ]
        }
    )
    print(payload)

testP("ASHOK", "CJAIJA")

def testAT(templateId, deviceCSV):
    payload = json.dumps({
      "deviceTemplateList": [
        {
          "templateId": f"{templateId}",
          "device": [
            deviceCSV,
          ],
          "isEdited": False,
          "isMasterEdited": False,
          "isDraftDisabled": False
        }
      ]
    })
    pprint(payload)

testAT("e817727c-d53f-466b-af56-1a0bc659c54b", tdata[0])

print(tdata[0]['csv-deviceId'])
def main():
    pass

if __name__ == '__main__':
    main()
