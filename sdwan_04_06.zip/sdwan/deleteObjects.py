#-------------------------------------------------------------------------------
# Author:      ashok.chauhan
#-------------------------------------------------------------------------------
from sdwan import *
from myXLS import *
wkGS = r"C:\00-Projects\00-WK\Firewall_rule_branch_v1.2.xlsx"


def main():
    c90 = mySDWAN(vManage="10.10.20.90", username = "admin", passcode="C1sco12345", gs="")
    apiList = ["/template/policy/list/dataprefix" , "/template/policy/list/port", "/template/policy/list/zone", '/template/policy/list/class']
    for apiItem in apiList:
        objects = c90.get(api=apiItem, method="GET", payload={})
        # print(objects)
        if objects.get('data', None):
            # check if empty
            data = objects.get('data', None)
            if len(data):
                # get a list of all items in the data
                for delItem in data:
                    print("Deleting object %s" % delItem['listId'])
                    url = f'{c90.baseUrl}{apiItem}/{delItem["listId"]}'
                    c90.s.delete(url, headers = c90.headers)

    pass

if __name__ == '__main__':
    main()
