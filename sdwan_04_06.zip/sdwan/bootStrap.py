#-------------------------------------------------------------------------------
# Author:      ashok.chauhan
#-------------------------------------------------------------------------------
from sdwan import *

def downloadBootstrapFile(sdwan, interface="GigabitEthernet1", deviceId=None):
    interface = "GigabitEthernet1"
    bs = f"/system/device/bootstrap/generic/devices?wanif={interface}"
    g = sdwan.get(api=bs)
    sdwan.downloadFile(api=f'/system/device/bootstrap/download/{g["id"]}')

def main():
    c90 = mySDWAN()
##    downloadBootstrapFile(c90)
    devices = c90.getVedges()
    print(devices)

if __name__ == '__main__':
    main()
