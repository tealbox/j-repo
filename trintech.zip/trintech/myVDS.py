
from myNSX import myNSX
import re
from readXl import *

import argparse, getpass
import sys, re
import time

from pyVmomi import vim, vmodl
from pyvim import connect
from pyvim.connect import Disconnect

import ssl
context = ssl.create_default_context()
context.check_hostname = False
context.verify_mode = ssl.CERT_NONE
def getVDS(vc='192.168.1.32',username="Administrator", password="VMware1!"):
    si = None
    try:
        print ("Trying to connect to VCENTER SERVER . . .")
        si = connect.Connect(vc, 443, username, password, sslContext=context)
    except IOError:
        pass
        atexit.register(Disconnect, si)

    print ("Connected to VCENTER SERVER !")

    content = si.RetrieveContent()
    container = content.viewManager.CreateContainerView(content.rootFolder, [vim.dvs.VmwareDistributedVirtualSwitch], True)
    vds = {}
    for c in container.view:
##        print(c.name, c.uuid)
        vds.setdefault(c.name, c.uuid)

    return vds