import re
from myNSX import myNSX
from readXl import *
import argparse, getpass
import sys, re
import time
from pyVmomi import vim, vmodl
from pyvim import connect
from myVDS import *
from pyvim.connect import Disconnect
import ssl
context = ssl.create_default_context()
context.check_hostname = False
context.verify_mode = ssl.CERT_NONE



def extract_numbers_from_end(s):
    numbers = re.findall(r'\d+$', s)
    if len(numbers):
        vlan = int(numbers[0])
        if 0<= vlan <= 4096:
            return int(numbers[0])
        else:
            print('%s: VLAN Format should be like xxxdddd & dddd must be in range 0-4096' % s)
            raise SystemExit()
    else:
        print('%s: VLAN Format should be like xxxdddd' % s)
        raise SystemExit()




class nsxProfile(myNSX):

    def __init__(self, nsxmgr, username = "admin", password = "VMware1!"):
        super().__init__(nsxmgr, username=username, password = password)
        self.mgrUrl = f"https://{nsxmgr}/api/v1"
        self.vds = getVDS(vc='192.168.1.32',username="Administrator", password="VMware1!")

    def getUplinkProfiles(self):
        api = "/host-switch-profiles"
        url = f"{self.mgrUrl}{api}"
        self.ups = {}
        results = self.get(api=url)
        for item in results['results']:
            self.ups.setdefault(item['display_name'], item['id'])

    def createUPPayload(self,name,file="ulProfilePayload.json"):
        import json
        with open(file) as f:
            payload = json.load(f)
            vlan = extract_numbers_from_end(name)
            payload['transport_vlan'] = vlan
            payload['display_name'] = name
            return json.dumps(payload)

    def createUplinkProfile(self,name,file="ulProfilePayload.json"):
        payload = self.createUPPayload(name,file)
        api = "/host-switch-profiles"
        url = f"{self.mgrUrl}{api}"
        self.getUplinkProfiles()
        if name in self.ups:
            print("Uplink Profile %s already exist" % name)
        else:
            print("Creating Uplink Profile %s"%name)
            self.post(api=url,payload=payload)

    def deletUplinkProfile(self,name,file="ulProfilePayload.json"):
        payload = self.createUPPayload(name,file)
        api = "/host-switch-profiles"
        url = f"{self.mgrUrl}{api}"
        self.post(api=url,payload=payload)

    def getipPool(self):
        api = "/pools/ip-pools"
        url = f"{self.mgrUrl}{api}"
        self.ippools = {}
        results = self.get(api=url)
        for item in results['results']:
            self.ippools.setdefault(item['display_name'], item['id'])


    def getTransportZones(self):
        api = "/transport-zones"
        url = f"{self.mgrUrl}{api}"
        self.tz = {}
        results = self.get(api=url)
        for item in results['results']:
            self.tz.setdefault(item['display_name'], item['id'])

    def createTNPPayload(self, name, vds, uplinkProfile, ippool, tz, file="tnpPayload.json"):
        import json
        self.getipPool()
        self.getTransportZones()
        self.getUplinkProfiles()
        if vds in self.vds:
            vds_id = self.vds[vds]
        else:
            print("DVS: %s is not in VC" % vds)
            return None

        if uplinkProfile in self.ups:
            uplinkProfile_id = self.ups[uplinkProfile]
        else:
            print("uplinkProfile: %s is not found" % uplinkProfile)
            return None

        if ippool in self.ippools:
            ippool_id = self.ippools[ippool]
        else:
            print("IP Pool: %s is not found" % ippool)
            return None
        tz_id = []
        if isinstance(tz, list):
            for item in tz:
                if item in self.tz:
                    tz_id.append(self.tz[item])
                else:
                    print("TransportZone: %s is not found" % item)
                    return None
        else:
            if tz in self.tz:
                tz_id = self.tz[tz]
            else:
                print("TransportZone: %s is not found" % tz)
                return None


        with open(file) as f:
            payload = json.load(f)
            host_switches = payload['host_switch_spec']['host_switches'][0]
            host_switches['host_switch_name'] = vds
            host_switches['host_switch_id'] = vds_id
            host_switches['host_switch_profile_ids'][0]['value'] = uplinkProfile_id
            host_switches['ip_assignment_spec']['ip_pool_id'] = ippool_id
            if isinstance(tz_id, list):
                transport_zone_endpoints = []
                for item in tz_id:
                    transport_zone_endpoints.append({"transport_zone_id": item,"transport_zone_profile_ids": []})
            else:
                transport_zone_endpoints = [ {"transport_zone_id": tz_id,"transport_zone_profile_ids": []}, ]

            payload['display_name'] = name

            payload['host_switch_spec']['host_switches'][0] = host_switches
            payload['host_switch_spec']['host_switches'][0]['transport_zone_endpoints'] = transport_zone_endpoints
##            print(payload)
            return json.dumps(payload)

    def createTNP(self, name, vds, uplinkProfile, ippool, tz, file="tnpPayload.json"):
        payload = self.createTNPPayload(name, vds, uplinkProfile, ippool, tz, file)
        api = "/transport-node-profiles"
        url = f"{self.mgrUrl}{api}"
        self.getTNPs()
        if payload is None:
            return None
        if name in self.tnps:
            print("Transport Node Profile %s already exist" % name)
        else:
            print("Creating Transport Node Profile %s"%name)
            self.post(api=url,payload=payload)

    def getTNPs(self):
        api = "/transport-node-profiles"
        url = f"{self.mgrUrl}{api}"
        self.tnps = {}
        results = self.get(api=url)
        for item in results['results']:
            self.tnps.setdefault(item['display_name'], item['id'])

class Password(argparse.Action):
    def __call__(self, parser, namespace, values, option_string):
        if values is None:
            values = getpass.getpass()

        setattr(namespace, self.dest, values)

def main():
    parser = argparse.ArgumentParser(description=":: PortGroup Create ::")
    parser.add_argument('-x', '--xls', dest="xls", type=str, default=None, required=True, help='input xls file')
    parser.add_argument('-n', '--nsxmgr', dest="nsxmgr", type=str, default=None, required=True, help='nsxmgr IP/FQDN')
    parser.add_argument('-u', '--username', dest="username", type=str, default=None, required=True,help='nsxmgr username')
    parser.add_argument('-p', action=Password, nargs='?', dest='password', help='nsxmgr Password')
    args = parser.parse_args()
    xlsFile = args.xls
    print("--"*25)
    a =  nsxProfile(nsxmgr=args.nsxmgr, username = args.username, password = args.password)
    ulprofiles = readColumns(xlsFile, sheet ='Values', col='D', row=16)

    a.getipPool()
    a.getTransportZones()
    a.getUplinkProfiles()

    a.createTNP(name='TNP-PDC1-F-VSI-TVL3755', vds='X90C4VCDC', uplinkProfile='UPP-PDC1-C-VSI-ESXI-CVDS-TVL3720', ippool='TEP_POOL', tz=['TZ_overlay','TZ_VLAN'])
    a.createTNP(name='TNP-PDC1-F-VSI-TVL2455', vds='X70E3VCDC', uplinkProfile='UPP-PDC1-C-VSI-ESXI-CVDS-TVL3720', ippool='TEP_POOL', tz=['TZ-PDC1-VL4041','TZ_VLAN','TZ_VLAN_4042'])

if __name__ == "__main__":
    main()