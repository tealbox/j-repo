#-------------------------------------------------------------------------------
# Author:      ashok.chauhan
#-------------------------------------------------------------------------------
from sdwan import *
from myXLS import *
from sdwan_utils.utils import *
wkGS = r"C:\00-Projects\00-WK\Firewall_rule_branch_v1.2.xlsx"
import functools
import time, json


c90 = mySDWAN(vManage="10.10.20.90", username = "admin", passcode="C1sco12345", gs="")
jdumps(c90.zoneByName())
jdumps(c90.dataPrefixByName())