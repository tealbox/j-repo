import click
from sdwan import *
from tabulate import tabulate
@click.command()
@click.option("--vmanage",  '-v', prompt="vManage IP", default='10.10.20.90', required=True)
@click.option("--username", '-u', prompt="vManage Username", default='admin', required=True)
@click.option("--password", '-p', prompt="Password", hide_input=True, required=True, default='C1sco12345')
def cli(vmanage, username, password):
    c90 = mySDWAN(vManage=vmanage,username=username, passcode=password)
    cEdges = c90.getVedges()
    cEdgesList = []
    for item in cEdges:
        if item['managed-by'] == 'Unmanaged':
            cEdgesList.append([item['chasisNumber'], item['uuid'], item['serialNumber'], item['deviceState'], item['managed-by']])
    print( tabulate(cEdgesList, headers=['chasisNumber', 'uuid', 'serialNumber','deviceState', 'managed-by']))
if __name__ == "__main__":
    cli()