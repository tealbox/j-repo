#-------------------------------------------------------------------------------
# Author:      ashok.chauhan
#-------------------------------------------------------------------------------

import click

class toy:
    def __init__(self, a,b):
        self.a = int(a)
        self.b = int(b)

    def sum(self, a, b):
        if self.a == 10:
            return self.a + self.b
        else:
            return int(a)+int(b)

    def getToy():
        print(f"{self.a} an {self.b}")

@click.group()
def cli():
    pass

pass_config = click.make_pass_decorator(toy, ensure=True)

t = toy(10,20)

@cli.command()
@pass_config
@click.option("-a", default=10)
@click.option("-b", default=20)
def getToy(ctx,a,b):
    ctx.getToy()

@cli.command()
@click.option("-a", default=10)
@click.option("-b", default=20)
def sum(a,b):
    t.sum(a,b)

if __name__ == '__main__':
    cli()