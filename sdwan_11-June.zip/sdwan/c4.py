import click

class command:
    def __init__(self, name=None, cls=click.Command, **attrs):
        self.name = name
        self.cls = cls
        self.attrs = attrs

    def __call__(self, method):
        def __command__(this):
            def wrapper(*args, **kwargs):
                return method(this, *args, **kwargs)

            return self.cls(self.name, callback=wrapper, **self.attrs)

        method.__command__ = __command__
        return method


class option:
    def __init__(self, *param_decls, **attrs):
        self.param_decls = param_decls
        self.attrs = attrs

    def __call__(self, method):
        if not hasattr(method, '__option__'):
            method.__options__ = []

        method.__options__.append(
            click.Option(param_decls=self.param_decls, **self.attrs))
        return method


class Cli:
    def __new__(cls, *args, **kwargs):
        self = super(Cli, cls).__new__(cls, *args, **kwargs)

        def cli(*args, **options):
            for callback in self.__option_callbacks__:
                callback(self, **options)

        self._cli = click.Group(callback=cli)

        # Wrap commands
        for attr_name in dir(cls):
            attr = getattr(cls, attr_name)
            if hasattr(attr, '__command__'):
                self._cli.add_command(attr.__command__(self))

        # Wrap instance options
        self.__option_callbacks__ = set()
        for attr_name in dir(cls):
            attr = getattr(cls, attr_name)
            if hasattr(attr, '__options__'):
                self._cli.params.extend(attr.__options__)
                self.__option_callbacks__.add(attr)
        return self

    def run(self):
        """Run the CLI application."""
        self()

    def __call__(self):
        """Run the CLI application."""
        self._cli()


class HeyDude(Cli):
##    @option('-n', '--name', default="Dude")
##    def set_name(self, name):
##        self._name = name

    @option('-a', '--age', default=45)
    def set_age(self, age):
        self._age = age

    @command('shout')
    def shout(self):
        print("HEY %s!" % self._name.upper())

    @command('greet')
    def bar(self):
        print("Hello %s!" % self._name)


    @command('sayHello')
    def sayHello(self):
        print("Hello %s!" % self._name)

    def bonus(self, sal):
        print("Bonus: ", sal*4)

    @command('getAge')
    def getAge(self):
        a = input("Your Sal: ")
        print("Hello %s!" % self._age)
        self.bonus(int(a))

HeyDude()()