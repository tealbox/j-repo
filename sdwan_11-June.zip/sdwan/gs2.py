import os
text = ["Some text 1 2 3 4 5 6 7 8 9 10 11 11 1 1 1111 1 1 1 1 1 1 1 11  1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 11 1 1 1 1 1 2 2 32  32  23 2 32323 232 32 323 2 323 2 323 23", "spread across", "several lines."]
from fpdf import FPDF

pdf = FPDF()

txt="Try using fastapi-profiler when looking for performance bottlenecks in your code. Here is simple configuration I used in one of my projects:.."
txt+=txt

pdf.add_page()
left_margin = 5
top_margin =  5
current_x = pdf.get_x()
current_y = pdf.get_y()
pdf.set_xy(current_x+left_margin, current_y+top_margin)
pdf.set_font('arial', 'B', 10.0)
pdf.set_text_color(0,0,0)
pdf.multi_cell(w=0, h=5.0, align='L',txt=txt)

current_x = pdf.get_x()
current_y = pdf.get_y()
pdf.set_text_color(0,255,0)
pdf.set_xy(current_x+left_margin, current_y)
pdf.multi_cell(w=0, h=5.0, align='L',txt=" >> PASS.")

current_x = pdf.get_x()
current_y = pdf.get_y()
pdf.set_text_color(0,0,0)
pdf.set_xy(current_x+left_margin, current_y)
pdf.multi_cell(w=0, h=5.0, align='L',txt=txt)
pdf.set_text_color(255,0,0)
current_x = pdf.get_x()
current_y = pdf.get_y()
pdf.set_xy(current_x+left_margin, current_y)
pdf.multi_cell(w=0, h=5.0, align='L',txt=" >> Fail.")
pdf.output(r"c:\temp\text.pdf", 'F')
print(os.getcwd())