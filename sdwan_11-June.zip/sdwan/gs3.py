from sdwan import *
from myXLS import *
wkGS = r"C:\00-Projects\00-WK\Firewall_rule_branch_v1.2.xlsx"
import functools
import time, json
from sdwan_utils.utils import *
##def timer(func):
##    @functools.wraps(func)
##    def wrapper(*args, **kwargs):
##        start_time = time.perf_counter()
##        value = func(*args, **kwargs)
##        end_time = time.perf_counter()
##        run_time = end_time - start_time
##        print("Finished {} in {} secs".format(repr(func.__name__), round(run_time, 3)))
##        return value
##
##    return wrapper
##
##@timer



from datetime import datetime
start = datetime.now()
# your code




wb = fast_openpyxl(wkGS)
zones = wb[1]["sheet_Zone"]
# print(zones)
zinterfaces = ["ethernet","fastethernet","fivegigabitethernet","fortygigabitethernet","gigabitethernet","hundredgige","loopback",
            "tengigabitethernet","tunnel","twentyfivegigabitethernet","twentyfivegige","twogigabitethernet","virtiualportgroup","vlan"]

##for item in zones:
##    zpayload = zoneItemParse(item)
##    payload = createListPayload(item["name"], "zone", zpayload)
##    t = c90.post(api='/template/policy/list/port', method="POST", payload=payload)
##    print(t)

ports = wb[1]["sheet_Port"]


##for item in ports:
##    parseItem =  portItemParse(item, "port" )
##    payload=createListPayload(item['name'], dtype="port", entries=parseItem)
##    print(payload)


end = datetime.now()
time_taken = end - start
print('Time: ',time_taken)

def main():
    c90 = mySDWAN(vManage="10.10.20.90", username = "admin", passcode="C1sco12345", gs="")
    payload = json.dumps({'name': 'testZone', 'type': 'zone', 'entries': [{'vpn': '511'}]})
    for item in zones:
        zpayload = zoneItemParse(item)
        payload = createListPayload(item["name"], "zone", zpayload)
        t = c90.post(api='/template/policy/list/zone', method="POST", payload=payload)
    print(t)
##
##    for item in ports:
##        parseItem =  portItemParse(item, "port" )
##        payload=createListPayload(item['name'], dtype="port", entries=parseItem)
####        print(payload)
##        t = c90.post(api='/template/policy/list/port', method="POST", payload=payload)

    pass
if __name__ == "__main__":
    main()