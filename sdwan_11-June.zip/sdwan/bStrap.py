import click
from sdwan import *
from hc_SearchClass import *
##@click.group()
##@click.pass_context
##def cli(ctx):
##    ctx.obj = sdwan.mySDWAN()

@click.command()
@click.option("--vmanage",  '-v', prompt="vManage IP", default='10.10.20.90', required=True)
@click.option("--username", '-u', prompt="vManage Username", default='admin', required=True)
@click.option("--password", '-p', prompt="Password", hide_input=True, required=True, default='C1sco12345')
@click.option("--device",   '-d', prompt="Device uuid(CAPS)", required=True)
def cli(vmanage, username, password, device):
    device = device
    c90 = mySDWAN(vManage=vmanage,username=username, passcode=password)
    srch = hcSearch(vManage=vmanage, headers=c90.headers)
    cEdges = srch.getCertEdges()
    if device.lower() in cEdges:
        deviceFile = f'{device}.cfg'
    ##    print(cEdges)
        data = c90.getBootStrapFile(device=device.upper(),wanif='wan0')
        if "bootstrapConfig" in data:
            with open(deviceFile, "w") as f:
                f.write(data['bootstrapConfig'])
            print("Successfully generated Bootstrap for %s, and filename %s" % (device,deviceFile))
        print(data)
    else:
        click.echo(f"Device {device} not found, Please   validate again")

if __name__ == "__main__":
    cli()