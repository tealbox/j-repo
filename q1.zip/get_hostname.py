#-------------------------------------------------------------------------------
# Name:        module1
#-------------------------------------------------------------------------------
from ciscoconfparse2 import CiscoConfParse

##file = 'eccsx100a-dfn.txt'
file = 'eccfn001.txt'
parse = CiscoConfParse(file, syntax='ios')

# Find the hostname
hostname = parse.find_objects(r"^hostname")
if hostname:
    print(f"Hostname: {hostname[0].text.split()[1]}")
else:
    print("Hostname not found.")

# Find VTP configuration
vtp_config = parse.find_objects(r"^vtp")
if vtp_config:
    print("\nVTP Configuration:")
    for line in vtp_config:
        print(line.text)
else:
    print("VTP configuration not found.")

# Find detailed VTP information
vtp_mode = parse.find_parent_objects_wo_child(parentspec=r"^vtp", childspec=r"mode")
vtp_domain = parse.find_parent_objects_wo_child(parentspec=r"^vtp", childspec=r"domain")
vtp_version = parse.find_parent_objects_wo_child(parentspec=r"^vtp", childspec=r"version")

print("\nDetailed VTP Information:")
if vtp_mode:
    print(f"VTP Mode: {vtp_mode[0].text.split()[2]}")
if vtp_domain:
    print(f"VTP Domain: {vtp_domain[0].text.split()[2]}")
if vtp_version:
    print(f"VTP Version: {vtp_version[0].text.split()[2]}")

ssh_version = parse.find_objects(r"^ssh\s+version")
print("SSH version", ssh_version[0].text)
def main():
    pass

if __name__ == '__main__':
    main()
